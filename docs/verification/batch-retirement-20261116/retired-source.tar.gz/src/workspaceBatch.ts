/** A batch groups explicit, independently prepared choices; it never authorizes future calls. */
export type WorkspaceBatchKind='voice'|'visual'|'captions';
export interface WorkspaceBatchCandidateAdoption {candidateId:string;adoptionId:string}
export interface WorkspaceBatchCaptionAdoption {clipId:string;taskId:string;expectedInputFingerprint:string}
export type WorkspaceBatchAdoptionInput={
 episodeId:string;workspaceId:string;expectedRevision:number;expectedProjectSha256:string;
}&({kind:'voice'|'visual';items:WorkspaceBatchCandidateAdoption[]}|{kind:'captions';items:WorkspaceBatchCaptionAdoption[]});
