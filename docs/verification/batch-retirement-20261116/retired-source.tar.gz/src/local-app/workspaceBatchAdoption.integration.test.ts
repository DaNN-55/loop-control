// @vitest-environment node
import {expect,it} from 'vitest';
import {isWorkspaceCandidateEdit} from '../workspaceCandidates';
import type {WorkspaceBatchCandidateAdoption} from '../workspaceBatch';
import {readFile,writeFile} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {mkdir} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import {csrfFor} from './sessions';
import {narrationFixture} from './workspaceNarration.fixture';
import {workspaceTestMedia} from './workspaceTestMedia.fixture';

it.skipIf(process.env.LOOP_WORKSPACE_ACCEPTANCE!=='1')('batch voice adoption validates the entire prepared set and commits one native revision, preserving unselected state',async()=>{
 const f=await narrationFixture();try{
  await f.authorize();let w=f.made;
  const send=async(name:string,data:Record<string,unknown>={})=>{
   const r=await f.request(name,{workspaceId:w.id,expectedRevision:w.revision,...data});expect(r.status,JSON.stringify(r.body)).toBe(200);return r.body;
  };
  for(const clip of w.clips){w=await send('saveWorkspaceNarration',{clipId:clip.id,mode:'tts',...f.narrationSettings,text:clip.text});w=await send('confirmWorkspaceNarration',{clipId:clip.id});}
  for(const clip of w.clips){w=await send('generateWorkspaceNarration',{clipId:clip.id,reservationCents:100});const task=w.narration.find((n:any)=>n.shotId===clip.shotId).taskId;await f.execute(task);}
  w=await f.read();expect(w.candidates.filter((v:any)=>v.status==='available')).toHaveLength(2);
  const baseline=JSON.parse(await readFile(join(f.assetRoot,w.project.relativePath),'utf8'));
  const entries:WorkspaceBatchCandidateAdoption[]=[];for(const candidate of w.candidates){const p=await send('prepareWorkspaceCandidate',{candidateId:candidate.id,durationPolicy:'use-candidate'});entries.push({candidateId:candidate.id,adoptionId:p.adoptionId});}
  const input={workspaceId:w.id,expectedRevision:w.revision,expectedProjectSha256:w.project.sha256,kind:'voice',items:entries};
  const changedClip=w.clips.find((clip:any)=>clip.shotId===w.candidates[0].shotId);
  w=await send('saveWorkspaceNarration',{clipId:changedClip.id,mode:'tts',...f.narrationSettings,speakingRate:1.1,text:changedClip.text});
  expect(w.project.sha256).toBe(input.expectedProjectSha256);
  expect((await f.request('adoptWorkspaceBatch',input)).status).toBe(409);
  expect((await f.read()).usedNarration).toHaveLength(0);
  w=await send('saveWorkspaceNarration',{clipId:changedClip.id,mode:'tts',...f.narrationSettings,text:changedClip.text});
  const bad=f.made.project.sha256===w.project.sha256?'b'.repeat(64):f.made.project.sha256;
  expect((await f.request('adoptWorkspaceBatch',{...input,expectedProjectSha256:bad})).status).toBe(409);
  expect((await f.request('adoptWorkspaceBatch',{...input,items:[entries[0],entries[0]]})).status).toBe(400);
  const second=w.candidates.find((v:any)=>v.id===entries[1].candidateId),file=join(f.assetRoot,second.relativePath),bytes=await readFile(file);
  await writeFile(file,Buffer.alloc(bytes.length));
  const invalid=await f.request('adoptWorkspaceBatch',input);expect(invalid.status,JSON.stringify(invalid.body)).toBe(409);
  const unchanged=await f.read();expect(unchanged.project.sha256).toBe(w.project.sha256);expect(unchanged.usedNarration).toHaveLength(0);
  expect((await f.c.query("SELECT count(*)::int n FROM local_identity.workspace_candidate_decisions WHERE workspace_id=$1 AND decision='adopted'",[w.id])).rows[0].n).toBe(0);
  await writeFile(file,bytes);
  const operation={command:'adoptWorkspaceBatch',idempotencyKey:randomUUID(),data:{episodeId:f.episode,...input}};
  const post=async()=>{const r=await fetch(f.origin+'/api/local/episode-commands',{method:'POST',headers:{Origin:f.origin,'Content-Type':'application/json',Cookie:'loop_owner_session='+f.token,'X-CSRF-Token':csrfFor(f.token)},body:JSON.stringify(operation)});return{status:r.status,body:await r.json()};};
  const adopted=await post();expect(adopted.status,JSON.stringify(adopted.body)).toBe(200);w=adopted.body;
  const replay=await post();expect(replay.status,JSON.stringify(replay.body)).toBe(200);expect(replay.body.project.sha256).toBe(w.project.sha256);expect(replay.body.revision).toBe(w.revision);
  expect(w.revision).toBe(input.expectedRevision+1);expect(w.usedNarration).toHaveLength(2);expect(w.candidates.every((v:any)=>v.status==='adopted')).toBe(true);
  const saved=JSON.parse(await readFile(join(f.assetRoot,w.project.relativePath),'utf8'));
  for(const before of baseline.timelines[0].items){const after=saved.timelines[0].items.find((i:any)=>i.id===before.id);expect(after).toMatchObject({volume:0,loopControlAudio:{voiceMode:'tts'}});const {volume:_,loopControlAudio:__,...unchanged}=after;expect(unchanged).toEqual(before);}
  expect((await f.request('adoptWorkspaceBatch',input)).status).toBe(409);
  await f.restart();expect((await f.read()).project.sha256).toBe(w.project.sha256);
 }finally{await f.close();}
},120000);

it.skipIf(process.env.LOOP_WORKSPACE_ACCEPTANCE!=='1')('batch visual adoption preserves individual prepared ranges and rejects stale inputs atomically',async()=>{
 const f=await narrationFixture();try{
  let w=f.made;
  const imported=await f.request('importMaterial',{materialType:'image',sourceKind:'file',sourcePath:'batch-reference.png',mimeType:'image/png',contentBase64:(await readFile(workspaceTestMedia('still-striped.png'))).toString('base64'),isMainScript:false,materialPurpose:'visual_reference'});expect(imported.status).toBe(200);
  for(const clip of w.clips){const r=await f.request('registerWorkspaceVisualCandidate',{workspaceId:w.id,expectedRevision:w.revision,targetItemId:clip.itemId,materialRevisionId:imported.body.id,usage:'still',durationSeconds:3});expect(r.status,JSON.stringify(r.body)).toBe(200);w=r.body;}
  const items=[];for(const candidate of w.visualCandidates){const p=await f.request('prepareWorkspaceVisualCandidate',{workspaceId:w.id,expectedRevision:w.revision,candidateId:candidate.id,durationPolicy:'keep-target',motionPolicy:'preserve-target'});expect(p.status,JSON.stringify(p.body)).toBe(200);items.push({candidateId:candidate.id,adoptionId:p.body.adoptionId});}
  const old=w;const input={workspaceId:w.id,expectedRevision:w.revision,expectedProjectSha256:w.project.sha256,kind:'visual',items};
  const denied=await f.request('adoptWorkspaceBatch',{...input,kind:'voice'});expect(denied.status).toBe(409);expect((await f.read()).project.sha256).toBe(old.project.sha256);
  const adopted=await f.request('adoptWorkspaceBatch',input);expect(adopted.status,JSON.stringify(adopted.body)).toBe(200);w=adopted.body;
  expect(w.revision).toBe(old.revision+1);expect(w.readiness.placeholders).toHaveLength(0);expect(w.visualCandidates.every((v:any)=>v.status==='adopted')).toBe(true);
  const doc=JSON.parse(await readFile(join(f.assetRoot,w.project.relativePath),'utf8'));expect(w.clips.every((clip:any)=>doc.timelines[0].items.some((i:any)=>i.id===clip.itemId&&i.kind==='image'))).toBe(true);
 }finally{await f.close();}
},120000);

it.skipIf(process.env.LOOP_WORKSPACE_ACCEPTANCE!=='1')('batch subtitle adoption applies only validated completed alignment results in one native revision',async()=>{
 const {nativeWorkerPort}=await import('./workerDatabase');
 const f=await narrationFixture(),worker=f.workerPool();try{
  await f.authorize();let w=f.made;
  const send=async(name:string,data:Record<string,unknown>={})=>{const r=await f.request(name,{workspaceId:w.id,expectedRevision:w.revision,...data});expect(r.status,JSON.stringify(r.body)).toBe(200);return r.body;};
  for(const clip of w.clips){w=await send('saveWorkspaceNarration',{clipId:clip.id,mode:'tts',...f.narrationSettings,text:clip.text});w=await send('confirmWorkspaceNarration',{clipId:clip.id});}
  for(const clip of w.clips){w=await send('generateWorkspaceNarration',{clipId:clip.id,reservationCents:100});await f.execute(w.narration.find((n:any)=>n.shotId===clip.shotId).taskId);}
  w=await f.read();const voices=[];
  for(const candidate of w.candidates){const p=await send('prepareWorkspaceCandidate',{candidateId:candidate.id,durationPolicy:'use-candidate'});voices.push({candidateId:candidate.id,adoptionId:p.adoptionId});}
  w=await send('adoptWorkspaceBatch',{expectedProjectSha256:w.project.sha256,kind:'voice',items:voices});
  const entries=[];
  for(const clip of w.clips){
   const queued=await send('requestWorkspaceCaptionAlignment',{clipId:clip.id,localOnly:true});w=queued.workspace;
   const task=queued.task,port=nativeWorkerPort(worker),claim=(await port.rpc('claim_next_worker_task',{p_task_id:task.id,p_worker_capacity:1}))[0] as Record<string,any>;expect(claim?.task_id).toBe(task.id);
   const frozen=claim.input_snapshot.acoustic_alignment;
   const alignment={version:'acoustic-alignment/v1',status:'completed',method:'local_whisperx',granularity:'phrase',inputVersion:frozen.input_version,audioSha256:frozen.audio_sha256,textFingerprint:frozen.text_fingerprint,provider:'whisperx',model:claim.model,connectionVersionId:null,wordCount:1,cues:[{id:'batch-aligned-'+clip.shotId,text:frozen.confirmed_text,startMs:120,endMs:980,confidence:.99}],reviewIssues:[],attempts:[],detail:'Controlled local aligner seam',generatedAt:new Date().toISOString()};
   const bytes=Buffer.from(JSON.stringify(alignment)),path=claim.input_snapshot.output.relative_path;
   await mkdir(dirname(join(f.assetRoot,path)),{recursive:true});await writeFile(join(f.assetRoot,path),bytes);
   await port.rpc('report_worker_result',{p_task_id:claim.task_id,p_attempt:claim.attempt,p_lease_token:claim.lease_token,p_result:{version:'worker-result/v1',taskId:claim.task_id,status:'completed',acousticAlignment:alignment,artifacts:[{artifactType:'acoustic_alignment_evidence',relativePath:path,sha256:createHash('sha256').update(bytes).digest('hex'),fileSize:bytes.length}],validation:{passed:true,checks:[{name:'batch_alignment',passed:true,detail:'Controlled native queue result'}]},actualCostCents:0,blockers:[],retry:{shouldRetry:false,reason:'completed'},nextStep:'Review'}});
   entries.push({clipId:clip.id,taskId:task.id,expectedInputFingerprint:w.captions.find((v:any)=>v.shotId===clip.shotId).inputFingerprint});
  }
  w=await f.read();const before=w;
  for(const item of entries){const prepared=await send('prepareWorkspaceCaptionAlignment',item);expect(prepared.captionContract.cues[0].startMs).toBe(120);}
  const input={workspaceId:w.id,expectedRevision:w.revision,expectedProjectSha256:w.project.sha256,kind:'captions',items:entries};
  const invalid=await f.request('adoptWorkspaceBatch',{...input,items:[entries[0],{...entries[1],expectedInputFingerprint:'a'.repeat(64)}]});expect(invalid.status,JSON.stringify(invalid.body)).toBe(409);
  expect((await f.read()).project.sha256).toBe(before.project.sha256);
  expect((await f.c.query("SELECT count(*)::int n FROM local_identity.workspace_caption_evidence WHERE workspace_id=$1 AND method='alignment'",[w.id])).rows[0].n).toBe(0);
  const adopted=await f.request('adoptWorkspaceBatch',input);expect(adopted.status,JSON.stringify(adopted.body)).toBe(200);w=adopted.body;
  expect(w.revision).toBe(before.revision+1);expect(w.captions.every((caption:any)=>caption.timing==='current'&&caption.contract.cues[0].startMs===120)).toBe(true);
  expect(w.usedNarration).toEqual(before.usedNarration);
  await f.restart();expect((await f.read()).captions.every((caption:any)=>caption.timing==='current')).toBe(true);
 }finally{await worker.end();await f.close();}
},120000);

it.skipIf(process.env.LOOP_WORKSPACE_ACCEPTANCE!=='1')('batch adoption rejects duplicate shots, foreign identities, missing CSRF and completed episodes',async()=>{
 const f=await narrationFixture();try{
  let w=f.made;const clip=w.clips[0],candidates=[];
  for(const name of ['first','second']){
   const imported=await f.request('importMaterial',{materialType:'image',sourceKind:'file',sourcePath:name+'.png',mimeType:'image/png',contentBase64:(await readFile(workspaceTestMedia('still-striped.png'))).toString('base64'),isMainScript:false,materialPurpose:'visual_reference'});expect(imported.status,JSON.stringify(imported.body)).toBe(200);
   const registered=await f.request('registerWorkspaceVisualCandidate',{workspaceId:w.id,expectedRevision:w.revision,targetItemId:clip.itemId,materialRevisionId:imported.body.id,usage:'still',durationSeconds:3});expect(registered.status,JSON.stringify(registered.body)).toBe(200);w=registered.body;
   candidates.push(w.visualCandidates.find((candidate:any)=>candidate.materialRevisionId===imported.body.id));
  }
  expect(new Set(candidates.map(c=>c.id)).size).toBe(2);
  const items=[];for(const candidate of candidates){const prepared=await f.request('prepareWorkspaceVisualCandidate',{workspaceId:w.id,expectedRevision:w.revision,candidateId:candidate.id,durationPolicy:'keep-target',motionPolicy:'preserve-target'});expect(prepared.status,JSON.stringify(prepared.body)).toBe(200);items.push({candidateId:candidate.id,adoptionId:prepared.body.adoptionId});}
  const input={workspaceId:w.id,expectedRevision:w.revision,expectedProjectSha256:w.project.sha256,kind:'visual',items};
  expect((await f.request('adoptWorkspaceBatch',input)).status).toBe(400);
  expect((await f.request('adoptWorkspaceBatch',{...input,items:[{...items[0],adoptionId:items[1].adoptionId}]})).status).toBe(409);
  expect((await f.request('adoptWorkspaceBatch',{...input,workspaceId:randomUUID(),items:[items[0]]})).status).toBe(409);
  expect((await f.request('adoptWorkspaceBatch',{...input,items:[{...items[0],candidateId:randomUUID()}]})).status).toBe(409);
  expect((await f.request('adoptWorkspaceBatch',{...input,items:[{...items[0],adoptionId:'-'.repeat(36)}]})).status).toBe(400);
  for(const kind of [['voice'],['visual'],null])expect((await f.request('adoptWorkspaceBatch',{...input,kind,items:[items[0]]})).status).toBe(400);
  expect((await f.request('adoptWorkspaceBatch',{...input,items:[items[0]]},{token:f.otherToken})).status).toBe(404);
  expect((await f.request('adoptWorkspaceBatch',{...input,items:[items[0]]},{csrf:false})).status).toBe(403);
  expect((await f.read()).project.sha256).toBe(w.project.sha256);
  await f.c.query("UPDATE public.episodes SET stage='production_completed' WHERE id=$1",[f.episode]);
  expect((await f.request('adoptWorkspaceBatch',{...input,items:[items[0]]})).status).toBe(409);
  expect((await f.c.query('SELECT project_sha256 FROM local_identity.production_workspaces WHERE id=$1',[w.id])).rows[0].project_sha256).toBe(w.project.sha256);
 }finally{await f.close();}
},120000);

it.skipIf(process.env.LOOP_WORKSPACE_ACCEPTANCE!=='1')('batch adopts real generated videos with separate registered source audio without applying native IPC path rules to stored edits',async()=>{
 const f=await narrationFixture(undefined,undefined,true);try{
  let w=f.made;
  const imported=await f.request('importMaterial',{materialType:'image',sourceKind:'file',sourcePath:'batch-video-reference.png',mimeType:'image/png',contentBase64:(await readFile(workspaceTestMedia('still-striped.png'))).toString('base64'),isMainScript:false,materialPurpose:'visual_reference'});expect(imported.status,JSON.stringify(imported.body)).toBe(200);
  for(const clip of w.clips){
   const queued=await f.chosenRequest('requestWorkspaceVisualCandidate',{workspaceId:w.id,expectedRevision:w.revision,targetItemId:clip.itemId,firstFrameMaterialRevisionId:imported.body.id,prompt:'保留参考图，轻缓展示当前镜头。',durationSeconds:4,reservationCents:100});expect(queued.status,JSON.stringify(queued.body)).toBe(200);w=queued.body;
   const task=w.visualTasks.find((task:any)=>task.targetItemId===clip.itemId);expect(task?.taskId).toBeTruthy();await f.execute(task.taskId);
  }
  w=await f.read();const candidates=w.visualCandidates.filter((candidate:any)=>candidate.kind==='video');expect(candidates).toHaveLength(2);
  const items:WorkspaceBatchCandidateAdoption[]=[];
  for(const candidate of candidates){
   const prepared=await f.request('prepareWorkspaceVisualCandidate',{workspaceId:w.id,expectedRevision:w.revision,candidateId:candidate.id,durationPolicy:'keep-target',motionPolicy:'preserve-target'});expect(prepared.status,JSON.stringify(prepared.body)).toBe(200);
   const stored=(await f.c.query('SELECT edit FROM local_identity.workspace_candidate_adoptions WHERE id=$1',[prepared.body.adoptionId])).rows[0].edit;
   expect(stored.videoSound.mode).toBe('separate');expect(stored.videoSound.asset.src).not.toMatch(/^\/media\/uploads\//);expect(isWorkspaceCandidateEdit(stored)).toBe(false);
   items.push({candidateId:candidate.id,adoptionId:prepared.body.adoptionId});
  }
  const before=w,input={workspaceId:w.id,expectedRevision:w.revision,expectedProjectSha256:w.project.sha256,kind:'visual',items};
  const stored=(await f.c.query('SELECT edit FROM local_identity.workspace_candidate_adoptions WHERE id=$1',[items[1].adoptionId])).rows[0].edit;
  const soundFile=join(f.assetRoot,stored.videoSound.asset.src),soundBytes=await readFile(soundFile);await writeFile(soundFile,Buffer.alloc(soundBytes.length));
  expect((await f.request('adoptWorkspaceBatch',input)).status).toBe(409);expect((await f.read()).project.sha256).toBe(before.project.sha256);await writeFile(soundFile,soundBytes);
  const adopted=await f.request('adoptWorkspaceBatch',input);
  expect(adopted.status,JSON.stringify(adopted.body)).toBe(200);w=adopted.body;expect(w.revision).toBe(before.revision+1);expect(w.visualCandidates.every((candidate:any)=>candidate.status==='adopted')).toBe(true);
  const project=JSON.parse(await readFile(join(f.assetRoot,w.project.relativePath),'utf8'));
  for(const candidate of candidates){const visual=project.timelines[0].items.find((item:any)=>item.id===candidate.targetItemId),sound=project.timelines[0].items.find((item:any)=>item.loopControlVideoSound?.videoItemId===candidate.targetItemId);expect(visual.kind).toBe('video');expect(project.assets.some((asset:any)=>asset.kind==='audio'&&asset.id.startsWith('material-'))).toBe(true);expect(sound).toBeTruthy();expect(sound.src).toBeTruthy();}
  await f.restart();expect((await f.read()).project.sha256).toBe(w.project.sha256);
 }finally{await f.close();}
},120000);
