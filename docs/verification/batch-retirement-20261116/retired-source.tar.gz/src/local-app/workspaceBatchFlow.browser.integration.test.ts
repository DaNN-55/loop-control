// @vitest-environment node
import {expect,it} from 'vitest';
import {createHash} from 'node:crypto';
import {mkdir,readFile,writeFile,copyFile} from 'node:fs/promises';
import {dirname,join} from 'node:path';
import {formalWorkflowFixture} from './formalWorkflow.fixture';
import {workspaceTestMedia} from './workspaceTestMedia.fixture';
import {storyBrowser} from './storyBrowser.fixture';
import {nativeWorkerPort} from './workerDatabase';
import {runWorkspaceDeliveryProcess} from './workspaceDelivery.fixture';
import {execFileSync} from 'node:child_process';

const script=`# 批量制作验收

## 制作设置
- 模板版本：3
- 画幅：9:16
- 镜头时长（秒）：2.4
- 字幕：开启
- 字幕最大行数：2
- 每行最大字数：14

## 正文
### 段落 01
- 口播：第一镜，保留产品全貌。
- 画面提示：正面展示同一产品，保留边缘。
- 视频提示词：正面静态展示同一产品，画面稳定。
- 画面来源：视频
- 素材名称：统一产品图

### 段落 02
- 口播：第二镜，展示产品细节。
- 画面提示：展示同一产品局部，保留原有文字。
- 视频提示词：展示同一产品细节，不改变文字和构图。
- 画面来源：视频
- 素材名称：统一产品图
`;

it.skipIf(process.env.LOOP_BATCH_BROWSER!=='1')('restored split workspace batches narration, video and subtitles through the real native project and export workflow',async()=>{
 if(!process.env.LOOP_TEST_CONTEXT_MODULE||!process.env.LOOP_STORY_EVIDENCE)throw Error('Explicit isolated context and evidence directory required');
 const evidence=process.env.LOOP_STORY_EVIDENCE;await mkdir(evidence,{recursive:true});
 const f=await formalWorkflowFixture({controlled:true,scriptText:script});
 let browser:Awaited<ReturnType<typeof storyBrowser>>|undefined;
 const worker=f.workerPool();
 try{
  const media=await f.send('importMaterial',{sourceKind:'file',sourcePath:'统一产品图.png',materialType:'image',materialPurpose:'visual_reference',mimeType:'image/png',isMainScript:false,contentBase64:(await readFile(workspaceTestMedia('still-striped.png'))).toString('base64')});expect(media.status,JSON.stringify(media.body)).toBe(200);
  expect((await f.send('start')).status).toBe(200);
  const made=await f.send('prepareWorkspace',{expectedScriptRevisionId:f.main});expect(made.status,JSON.stringify(made.body)).toBe(200);let w=made.body;
  expect(w.clips).toHaveLength(2);
  expect((await f.send('saveWorkspaceNarrationDefaults',{workspaceId:w.id,expectedRevision:w.revision,...f.controlled!.narrationSettings})).status).toBe(200);
  const read=async()=>{const r=await fetch(f.origin+`/api/local/episodes/${f.newEpisode}/workspace`,{headers:{Cookie:'loop_owner_session='+f.token}});expect(r.status).toBe(200);return(await r.json()).workspace;};
  const title=(await f.c.query('SELECT title FROM public.episodes WHERE id=$1',[f.newEpisode])).rows[0].title;
  browser=await storyBrowser({...f,episode:f.newEpisode},'batch-flow',title);
  const b=browser;
  await b.wait('document.querySelector(".workspace-batch-preparation") !== null');
  await b.cli('set','viewport','1410','952');
  const prefix=async(text:string)=>{
   await b.wait(`Array.from(document.querySelectorAll('button')).some(e=>e.getBoundingClientRect().width>0&&!e.disabled&&(e.getAttribute('aria-label')||e.textContent).trim().startsWith(${JSON.stringify(text)}))`);
   const name=await b.evaluate(`Array.from(document.querySelectorAll('button')).filter(e=>e.getBoundingClientRect().width>0&&!e.disabled).map(e=>(e.getAttribute('aria-label')||e.textContent).trim()).find(t=>t.startsWith(${JSON.stringify(text)}))`);
   if(typeof name!=='string')throw Error('No enabled button: '+text+'\n'+await b.snapshot());await b.click(name);
  };
  const waitReady=()=>b.wait(`Array.from(document.querySelectorAll('.batch-workspace-toolbar button')).some(e=>e.textContent.includes('集中核对')&&!e.disabled)`);
  const adopt=async(kind:string)=>{
   await waitReady();await prefix('集中核对');
   await b.wait(`Array.from(document.querySelectorAll('dialog[open] h3,dialog[open] h2')).some(e=>e.textContent.includes('集中核对'))`);
   for(let n=0;n<2;n++){await b.wait('document.querySelector(".batch-review-controls .batch-primary")?.disabled === false');await b.cli('click','.batch-review-controls .batch-primary');}
   await prefix('采用已通过');await prefix('确认采用');
   await b.wait(`!Array.from(document.querySelectorAll('dialog[open]')).some(e=>e.textContent.includes('采用前核对'))`);
   await b.wait(`document.querySelector('.batch-workspace-toolbar select[aria-label=\"筛选镜头\"] option[value=\"adopted\"]')?.textContent.includes('已采用 2')`);
   await b.capture(kind+'-adopted');
  };
  // The UI builds per-shot requests and the existing command receipt recovers a dropped response.
  await b.cli('select','select[aria-label="批量准备内容"]','voice');await prefix('批量准备');
  await b.wait(`Array.from(document.querySelectorAll('dialog[open]')).some(e=>e.textContent.includes('批量准备'))`);
  expect(await b.evaluate('document.querySelectorAll(".batch-confirm-entry").length')).toBe(2);
  await b.capture('voice-confirm');b.dropNextResponse('confirmWorkspaceCall');await prefix('确认准备');
  await b.wait(`document.querySelector('.batch-submission-record')?.textContent.includes('2 / 2')`);
  w=await read();const voiceTasks=w.narration.map((n:any)=>n.taskId).filter(Boolean);expect(new Set(voiceTasks).size).toBe(2);
  expect((await f.c.query("SELECT count(*)::int n FROM public.tasks WHERE episode_id=$1 AND task_type='generate_narration'",[f.newEpisode])).rows[0].n).toBe(2);
  for(const task of voiceTasks)expect((await f.controlled!.execute(task))?.status).toBe('completed');
  await waitReady();await prefix('集中核对');await b.click('通过并下一条');
  await b.cli('press','Escape');await b.cli('open',String(await b.evaluate('location.href'))+'&reload='+Date.now());await waitReady();await prefix('集中核对');
  expect(await b.evaluate('document.querySelectorAll("dialog[open] input[type=checkbox]:checked").length')).toBe(1);
  await b.cli('press','Escape');
  await adopt('voice');w=await read();expect(w.usedNarration).toHaveLength(2);
  // Seed only a previously saved shared model choice. Prompts, duration and first frames come from each real script/template target.
  await b.evaluate(`sessionStorage.setItem('loop-video-default:'+${JSON.stringify(w.id)},JSON.stringify({videoSelection:${JSON.stringify(f.controlled!.videoSelection)}}));true`);
  await b.cli('select','select[aria-label="批量准备内容"]','visual');await prefix('批量准备');await b.wait(`Array.from(document.querySelectorAll('dialog[open] h3')).some(e=>e.textContent.includes('批量准备'))`);await b.capture('visual-confirm');await prefix('确认准备');
  await b.wait(`document.querySelector('.batch-submission-record')?.textContent.includes('2 / 2')`);w=await read();
  const videoTasks=w.visualTasks.filter((t:any)=>t.kind==='video').map((t:any)=>t.taskId);expect(new Set(videoTasks).size).toBe(2);
  for(const task of videoTasks)expect((await f.controlled!.execute(task))?.status).toBe('completed');
  await adopt('visual');w=await read();expect(w.readiness.placeholders).toHaveLength(0);
  await b.cli('select','select[aria-label="批量准备内容"]','captions');await prefix('批量准备');await prefix('确认准备');
  await b.wait(`document.querySelector('.batch-submission-record')?.textContent.includes('2 / 2')`);w=await read();
  const port=nativeWorkerPort(worker);
  for(const caption of w.captions){
   const claim=(await port.rpc('claim_next_worker_task',{p_task_id:caption.taskId,p_worker_capacity:1}))[0] as Record<string,any>;expect(claim?.task_id).toBe(caption.taskId);
   const frozen=claim.input_snapshot.acoustic_alignment;
   const alignment={version:'acoustic-alignment/v1',status:'completed',method:'local_whisperx',granularity:'phrase',inputVersion:frozen.input_version,audioSha256:frozen.audio_sha256,textFingerprint:frozen.text_fingerprint,provider:'whisperx',model:claim.model,connectionVersionId:null,wordCount:1,cues:[{id:'aligned-'+caption.shotId,text:frozen.confirmed_text,startMs:100,endMs:2200,confidence:.99}],reviewIssues:[],attempts:[],detail:'Controlled aligner boundary; real task publication and native subtitle application.',generatedAt:new Date().toISOString()};
   const bytes=Buffer.from(JSON.stringify(alignment)),path=claim.input_snapshot.output.relative_path;
   await mkdir(dirname(join(f.assetRoot,path)),{recursive:true});await writeFile(join(f.assetRoot,path),bytes);
   await port.rpc('report_worker_result',{p_task_id:claim.task_id,p_attempt:claim.attempt,p_lease_token:claim.lease_token,p_result:{version:'worker-result/v1',taskId:claim.task_id,status:'completed',acousticAlignment:alignment,artifacts:[{artifactType:'acoustic_alignment_evidence',relativePath:path,sha256:createHash('sha256').update(bytes).digest('hex'),fileSize:bytes.length}],validation:{passed:true,checks:[{name:'controlled_alignment',passed:true,detail:'Deterministic boundary output'}]},actualCostCents:0,blockers:[],retry:{shouldRetry:false,reason:'completed'},nextStep:'Owner review'}});
  }
  await adopt('captions');w=await read();expect(w.captions.every((c:any)=>c.timing==='current')).toBe(true);
  const reopenUrl=String(await b.evaluate(`(()=>{const url=new URL(location.href);url.searchParams.set('step','preparation');return url.href;})()`));
  await b.cli('open',reopenUrl+'&reopen='+Date.now());await b.wait('document.querySelector(".workspace-batch-preparation") !== null');
  await b.capture('complete');
  const viewports=[];
  for(const width of [320,768,1024,1410]){await b.cli('set','viewport',String(width),'952');const layout=await b.evaluate('({width:innerWidth,body:document.documentElement.scrollWidth})');expect(layout.body).toBeLessThanOrEqual(width);viewports.push(layout);if(width===320)await b.capture('mobile');}
  await writeFile(join(evidence,'viewports.json'),JSON.stringify(viewports,null,2)+'\n');
  const before=w.project.sha256;
  const exported=await f.send('exportWorkspace',{workspaceId:w.id,expectedRevision:w.revision});expect(exported.status,JSON.stringify(exported.body)).toBe(200);w=exported.body;
  expect(w.exports[0].status,JSON.stringify(w.exports[0])).toBe('ready');expect(w.exports[0].project.sha256).toBe(before);
  const artifact=w.exports[0].artifact;expect(artifact.fileSize).toBeGreaterThan(1000);await copyFile(join(f.assetRoot,artifact.relativePath),join(evidence,'batch-final.mp4'));
  const confirmed=await f.send('confirmWorkspaceExport',{workspaceId:w.id,expectedRevision:w.revision,exportId:w.exports[0].id,expectedExportSha256:artifact.sha256,expectedContentSha256:w.contentSha256});expect(confirmed.status,JSON.stringify(confirmed.body)).toBe(200);w=confirmed.body;
  const delivery=await f.send('prepareWorkspaceDelivery',{workspaceId:w.id,expectedRevision:w.revision,exportId:w.exports[0].id,expectedExportSha256:artifact.sha256,expectedContentSha256:w.contentSha256,title:'批量制作验收',description:'受控供应商任务，真实原生工程与交付包。',tags:['批量验收'],coverBase64:(await readFile(workspaceTestMedia('still-striped.png'))).toString('base64')});expect(delivery.status,JSON.stringify(delivery.body)).toBe(200);w=delivery.body;
  const deliveryClaim=(await port.rpc('claim_next_worker_task',{p_task_id:w.deliveries[0].taskId,p_worker_capacity:1}))[0] as Record<string,any>;expect(deliveryClaim?.task_id).toBe(w.deliveries[0].taskId);
  expect((await runWorkspaceDeliveryProcess(f,deliveryClaim as any)).status).toBe('completed');w=await read();expect(w.deliveries[0].verified).toBe(true);
  const download=await fetch(f.origin+`/api/local/episodes/${f.newEpisode}/delivery-download?delivery=${w.deliveries[0].id}`,{headers:{Cookie:'loop_owner_session='+f.token}});expect(download.status).toBe(200);
  const zip=join(evidence,'batch-delivery.zip');await writeFile(zip,Buffer.from(await download.arrayBuffer()));expect(execFileSync('unzip',['-t',zip],{encoding:'utf8'})).toContain('No errors');
  await f.restart();w=await read();expect(w.usedNarration).toHaveLength(2);expect(w.captions.every((c:any)=>c.timing==='current')).toBe(true);expect(w.exports[0].status).toBe('ready');expect(w.deliveries[0].verified).toBe(true);
  const finalProject=JSON.parse(await readFile(join(f.assetRoot,w.project.relativePath),'utf8'));await writeFile(join(evidence,'native-project.json'),JSON.stringify(finalProject,null,2)+'\n');
  const errors=await b.cli('errors');expect(errors.errors??[]).toEqual([]);
  await writeFile(join(evidence,'acceptance.json'),JSON.stringify({passed:true,episodeId:f.newEpisode,voiceTasks,videoTasks,captionTasks:w.captions.map((c:any)=>c.taskId),projectSha256:w.project.sha256,exportSha256:artifact.sha256,exportBytes:artifact.fileSize,providerMode:'controlled',externalProviderCalls:0,actualMp4Export:true,verifiedDelivery:true,deliveryId:w.deliveries[0].id,traffic:b.traffic},null,2)+'\n');
 }catch(error){await browser?.capture('failure').catch(()=>{});throw error;}
 finally{await browser?.close();await worker.end();await f.close();}
},600000);
