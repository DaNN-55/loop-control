import {useEffect,useRef,useState} from 'react';
import {uiText} from '../i18n/ui';
import type {ProductionWorkspace} from '../productionWorkspace';
import type {WorkspaceVisualCandidate} from '../workspaceVisualCandidates';
import type {WorkspaceBatchKind} from '../workspaceBatch';
import type {ShotCaptionContract} from '../shotCaptions';
import {Button} from '../ui/dan-ui/components/base/buttons/button';
import {NativeSelect} from '../ui/dan-ui/components/base/select/select-native';
import {VideoPreview} from '../ui/media/VideoPreview';
import {ImagePreview} from '../ui/media/ImagePreview';
import type {BatchPreparationRow,BatchCommand} from './workspaceBatchPreparationModel';

export function WorkspaceBatchReview({workspace:w,kind,rows,choices,passed,disabled,command,onChoice,onPass,onAdopt,onClose}:{workspace:ProductionWorkspace;kind:WorkspaceBatchKind;rows:BatchPreparationRow[];choices:Record<string,string>;passed:Record<string,boolean>;disabled:boolean;command:BatchCommand;onChoice:(shotId:string,candidateId:string)=>void;onPass:(shotId:string,pass:boolean)=>void;onAdopt:()=>void;onClose:()=>void}){
 const [selected,setSelected]=useState(rows[0]?.shotId??''),[preview,setPreview]=useState<{identity:string;contract:ShotCaptionContract}|null>(null),[previewError,setPreviewError]=useState('');
 const sequence=useRef(0),nextButton=useRef<HTMLButtonElement>(null);
 const row=rows.find(r=>r.shotId===selected)??rows[0],index=rows.findIndex(r=>r.shotId===row?.shotId),candidate=row?.candidates.find(c=>c.id===choices[row.shotId])??row?.candidates[0];
 const caption=w.captions?.find(c=>c.shotId===row?.shotId),identity=JSON.stringify([w.id,w.project.sha256,row?.shotId,caption?.taskId,caption?.inputFingerprint]);
 useEffect(()=>{
  const request=++sequence.current;setPreview(null);setPreviewError('');
  // A changed input discovered during adoption preflight must be reviewed again,
  // rather than starting a new preview request under the old review visit.
  if(!disabled&&kind==='captions'&&row&&caption?.taskId)void command('prepareWorkspaceCaptionAlignment',{episodeId:w.episodeId,workspaceId:w.id,expectedRevision:w.revision,clipId:row.clipId,taskId:caption.taskId,expectedInputFingerprint:caption.inputFingerprint}).then(value=>{if(request===sequence.current)setPreview({identity,contract:(value as {captionContract:ShotCaptionContract}).captionContract});}).catch(error=>{if(request===sequence.current)setPreviewError(error instanceof Error?error.message:'字幕预览读取失败。');});
  return()=>{sequence.current++;};
 },[kind,identity]);
 const contract=preview?.identity===identity?preview.contract:null,canPass=kind==='captions'?!!contract:!!candidate;
 const approved=rows.filter(r=>passed[r.shotId]).length;
 function next(mark=false){if(!row)return;if(mark&&canPass)onPass(row.shotId,true);if(rows[index+1])setSelected(rows[index+1].shotId);requestAnimationFrame(()=>nextButton.current?.focus());}
 const url=(path:string)=>'/_local-artifact?'+new URLSearchParams({episode:w.episodeId,path});
 return <><div className="batch-review-meta"><strong>{rows.length} {uiText('个候选')}</strong><span>{uiText('逐项核对，通过后再采用。')}</span></div><div className="batch-review-grid">
  <div className="batch-review-list" role="group" aria-label={uiText('待核对候选')}>{rows.map(r=><div key={r.shotId} data-current={r.shotId===row?.shotId||undefined}><label><input type="checkbox" aria-label={uiText('镜头 {id} 核对通过',{id:r.shotId})} checked={!!passed[r.shotId]} disabled={disabled||kind==='captions'&&(r.shotId!==row?.shotId||!canPass)} onChange={e=>onPass(r.shotId,e.target.checked)}/></label><button type="button" disabled={disabled} aria-current={r.shotId===row?.shotId?'true':undefined} onClick={()=>setSelected(r.shotId)}><strong>{uiText('镜头')} {r.shotId}</strong><small>{r.text}</small></button></div>)}</div>
  <article className="batch-review-detail">{row?<><p className="batch-muted">{index+1} / {rows.length}</p><h4>{uiText('镜头')} {row.shotId}</h4>
   {candidate&&<><label className="batch-candidate-select">{uiText('候选')}<NativeSelect aria-label={uiText('镜头 {id} 候选',{id:row.shotId})} value={candidate.id} disabled={disabled} onChange={e=>onChoice(row.shotId,e.target.value)}>{row.candidates.map((c,i)=><option key={c.id} value={c.id}>{uiText('候选')} {i+1} · {c.durationSeconds.toFixed(2)} s</option>)}</NativeSelect></label>
    {kind==='voice'?<><p className="batch-narration">{candidate.text}</p><audio key={candidate.id} controls preload="metadata" src={url(candidate.relativePath)} aria-label={uiText('镜头 {id} 口播试听',{id:row.shotId})}/></>:<div className="batch-media">{candidate.kind==='image'?<ImagePreview src={url(candidate.relativePath)} alt={candidate.text||row.text}/>:<VideoPreview key={candidate.id} src={url(candidate.relativePath)} title={uiText('镜头 {id} 候选预览',{id:row.shotId})}/>}</div>}
    {kind==='visual'&&(candidate as WorkspaceVisualCandidate).generation&&<p className="batch-muted">{(candidate as WorkspaceVisualCandidate).generation?.prompt}</p>}
    <dl className="batch-review-facts"><div><dt>{uiText('候选时长')}</dt><dd>{candidate.durationSeconds.toFixed(2)} s</dd></div><div><dt>{uiText('当前镜头')}</dt><dd>{row.durationSeconds?.toFixed(2)??'—'} s</dd></div></dl>
   </>}
   {kind==='captions'&&<>{previewError?<p role="alert">{previewError}</p>:contract?<><p className="batch-narration">{contract.text}</p><div className="batch-caption-preview">{contract.cues.map(c=><p key={c.id}><span>{(c.startMs/1000).toFixed(2)}–{(c.endMs/1000).toFixed(2)} s</span>{c.text}</p>)}</div><p className="batch-muted">{uiText('已完成对齐的候选时序；采用后更新工程字幕。')}</p></>:<p role="status">{uiText('正在读取字幕对齐结果…')}</p>}</>}
   <div className="batch-review-controls"><Button size="sm" color="secondary" isDisabled={disabled||index===0} onPress={()=>setSelected(rows[index-1].shotId)}>{uiText('上一条')}</Button><Button size="sm" color="secondary" isDisabled={disabled||index===rows.length-1} onPress={()=>next()}>{uiText('下一条')}</Button><button ref={nextButton} type="button" className="batch-primary" disabled={disabled||!canPass} onClick={()=>next(true)}>{uiText(passed[row.shotId]?'已通过，下一条':'通过并下一条')}</button></div>
  </>:<p>{uiText('当前没有待核对结果。')}</p>}</article>
 </div><footer className="batch-dialog-footer"><span>{uiText('已通过')} {approved} / {rows.length} {uiText('项')}</span><Button size="sm" color="tertiary" isDisabled={disabled} onPress={onClose}>{uiText('稍后继续')}</Button><Button size="sm" color="primary" isDisabled={disabled||!approved} onPress={onAdopt}>{uiText('采用已通过的 {count} 项',{count:String(approved)})}</Button></footer></>;
}
