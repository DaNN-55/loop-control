import {createContext,useContext} from 'react';

interface BatchSelection {
 selectedShotIds:string[];visibleShotIds:string[];disabled:boolean;
 onChange:(shotIds:string[])=>void;
}
export const WorkspaceBatchSelectionContext=createContext<BatchSelection|null>(null);
export const useWorkspaceBatchSelection=()=>useContext(WorkspaceBatchSelectionContext);
