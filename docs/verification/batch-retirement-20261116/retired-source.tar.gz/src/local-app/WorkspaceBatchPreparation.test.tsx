import {useState} from 'react';
import {afterEach,beforeAll,expect,it,vi} from 'vitest';
import {cleanup,fireEvent,render,screen,waitFor,within} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {WorkspaceBatchPreparation} from './WorkspaceBatchPreparation';
import {WorkspaceModelPicker} from './WorkspaceModelPicker';
import {WorkspaceShotTable} from './WorkspaceShotTable';
import {WorkspaceDraftOwner} from './WorkspaceDraft';
import type {ProductionWorkspace} from '../productionWorkspace';
import {defaultShotCaptionContract} from '../shotCaptions';
import type {OpenChatCutProject} from '../worker/openchatcutProject';
beforeAll(()=>{HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','');};HTMLDialogElement.prototype.close=function(){this.removeAttribute('open');this.dispatchEvent(new Event('close'));};});
afterEach(()=>{cleanup();localStorage.clear();sessionStorage.clear();vi.unstubAllGlobals();});
const selection={capability:'speech' as const,provider:'volcengine_tts',adapter:'volcengine_tts',model:'seed-tts-2.0',connectionVersionId:'connection'};
function setup(ready=false){
 let w={id:'w',episodeId:'e',revision:1,stale:false,project:{sha256:'sha'},clips:['01','02'].map(id=>({id:'c'+id,itemId:'v'+id,shotId:id,text:'口播'+id,source:null})),narration:['01','02'].map(id=>({clipId:'c'+id,shotId:id,mode:'tts',enabled:true,text:'口播'+id,voice:'voice',languageCode:'zh-CN',speakingRate:1,selection,inputFingerprint:'voice-input-'+id,status:'pending',defaults:{selection,voice:'voice',languageCode:'zh-CN',speakingRate:1}})),candidates:ready?['01','02'].map(id=>({id:'candidate'+id,kind:'audio',shotId:id,clipId:'c'+id,targetItemId:'n'+id,relativePath:'voice'+id+'.mp3',sha256:'a'+id,inputFingerprint:'f'+id,durationSeconds:2,text:'口播'+id,status:'available'})):[]} as unknown as ProductionWorkspace;
 const project={timelines:[{id:'timeline',fps:30,items:w.clips.map((c,i)=>({id:c.itemId,startFrame:i*60,durationInFrames:60,kind:'text'}))}]} as unknown as OpenChatCutProject;
 vi.stubGlobal('fetch',vi.fn(async(path:string)=>({ok:true,json:async()=>path.includes('service-catalog')?{serviceCatalog:{version:1,groups:[]}}:{workspace:w}})));
 const command=vi.fn(async(name:string,data:any):Promise<unknown>=>{
  if(name==='prepareWorkspaceCall')return {confirmationId:data.callData.clipId,expiresAt:'2099-01-01',summary:{target:data.callData.clipId,kind:'口播生成',provider:'provider',model:'model',connection:'connection',prompt:'本镜正文',parameters:[],inputs:[],reservationCents:10,estimate:{minimumCents:1,maximumCents:100,suggestedCents:10}}};
  if(name==='prepareWorkspaceCandidate')return {candidateId:data.candidateId,adoptionId:'token-'+data.candidateId,projectSha256:w.project.sha256,impact:{currentSeconds:2,sourceSeconds:2,appliedSeconds:2,deltaSeconds:0,affectedFragments:[]}};
  if(name==='adoptWorkspaceBatch')w={...w,revision:2,project:{...w.project,sha256:'new-sha'},candidates:w.candidates?.map(c=>data.items.some((i:any)=>i.candidateId===c.id)?{...c,status:'adopted'}:c),narration:w.narration?.map(n=>data.items.some((i:any)=>i.candidateId==='candidate'+n.shotId)?{...n,adoptedAudioTrackId:'track'}:n)};
  return w;
 });
 const onSelect=vi.fn();function Harness(){const[current,change]=useState(w);return <WorkspaceDraftOwner ownerId="owner"><WorkspaceBatchPreparation workspace={current} project={project} pending={false} command={command} onChange={change}><WorkspaceShotTable workspace={current} project={project} materials={[]} selectedShotId="01" disabled={false} onSelect={onSelect} onDelete={vi.fn()} onEdit={async()=>{}}/><p>原镜头详情</p></WorkspaceBatchPreparation></WorkspaceDraftOwner>;}
 return {w,project,command,onSelect,Harness};
}
it('opens single-shot model choices in the permanent workspace without a second detail dialog',async()=>{
 const {w,project,command}=setup();
 const change=vi.fn(),user=userEvent.setup();
 render(<WorkspaceDraftOwner ownerId="owner"><WorkspaceBatchPreparation workspace={w} project={project} pending={false} command={command} onChange={vi.fn()}><WorkspaceModelPicker label="口播来源" title="选择语音模型" searchLabel="筛选语音模型" value="" options={[{id:'speech',label:'seed-tts-2.0'}]} onChange={change}/></WorkspaceBatchPreparation></WorkspaceDraftOwner>);
 expect(screen.queryByRole('dialog')).toBeNull();
 fireEvent.click(screen.getByRole('button',{name:'口播来源'}));
 const option=await screen.findByRole('menuitemradio',{name:'seed-tts-2.0'});
 expect(option.closest('dialog')).toBeNull();
 await user.click(option);expect(change).toHaveBeenCalledWith('speech');
 expect(document.querySelector('dialog[open]')).toBeNull();
});
it('uses selection in the original shot table and confirms preparation once without generating before confirmation',async()=>{
 const {Harness,command}=setup();render(<Harness/>);
 fireEvent.click(screen.getByRole('checkbox',{name:'选择镜头 01'}));fireEvent.click(screen.getByRole('button',{name:'批量准备 1'}));
 const dialog=await screen.findByRole('dialog',{name:'批量准备 · 口播'});expect(command.mock.calls.filter(([name])=>name==='prepareWorkspaceCall')).toHaveLength(1);
 expect(command.mock.calls.some(([name])=>name==='generateWorkspaceNarration'||name==='confirmWorkspaceCall')).toBe(false);
 fireEvent.click(within(dialog).getByRole('button',{name:'确认准备 1 项'}));await waitFor(()=>expect(command).toHaveBeenCalledWith('confirmWorkspaceCall',expect.objectContaining({confirmationId:'c01'})));
});
it('keeps batch selection separate from the active shot and filters only the single original list',()=>{
 const {Harness,command,onSelect}=setup(true);render(<Harness/>);
 fireEvent.click(screen.getByRole('checkbox',{name:'选择镜头 01'}));
 expect(onSelect).not.toHaveBeenCalled();expect(screen.getByText('已选择 1 个镜头')).toBeTruthy();
 fireEvent.change(screen.getByRole('combobox',{name:'筛选镜头'}),{target:{value:'adopted'}});
 expect(screen.getByText('当前筛选没有镜头。')).toBeTruthy();expect(screen.getByText('原镜头详情')).toBeTruthy();
 expect(screen.getByRole('checkbox',{name:'选择当前列表全部镜头'})).toHaveProperty('disabled',true);
 fireEvent.change(screen.getByRole('combobox',{name:'筛选镜头'}),{target:{value:'all'}});
 fireEvent.click(screen.getByRole('checkbox',{name:'选择当前列表全部镜头'}));
 fireEvent.click(screen.getByRole('checkbox',{name:'选择镜头 01'}));
 expect(screen.getByRole('checkbox',{name:'选择当前列表全部镜头'})).toHaveProperty('indeterminate',true);
 expect(screen.getByRole('checkbox',{name:'选择镜头 02'})).toHaveProperty('checked',true);
 fireEvent.click(screen.getByRole('button',{name:'选择镜头 01'}));
 expect(onSelect).toHaveBeenCalledWith('01');expect(screen.getAllByRole('table')).toHaveLength(1);expect(command).not.toHaveBeenCalled();
});
it('requires explicit review and one adoption confirmation, calling only the atomic batch endpoint',async()=>{
 const {Harness,command}=setup(true);render(<Harness/>);fireEvent.click(screen.getByRole('button',{name:'集中核对 2'}));
 const review=await screen.findByRole('dialog',{name:'集中核对 · 口播'});expect(within(review).getByRole('button',{name:'采用已通过的 0 项'})).toHaveProperty('disabled',true);
 fireEvent.click(within(review).getByRole('button',{name:'通过并下一条'}));fireEvent.click(within(review).getByRole('button',{name:'采用已通过的 1 项'}));
 const confirm=await screen.findByRole('dialog',{name:'采用前核对 · 口播'});expect(command.mock.calls.some(([name])=>name==='adoptWorkspaceBatch')).toBe(false);
 fireEvent.click(within(confirm).getByRole('button',{name:'确认采用 1 项'}));await waitFor(()=>expect(command).toHaveBeenCalledWith('adoptWorkspaceBatch',expect.objectContaining({kind:'voice',expectedProjectSha256:'sha',items:[{candidateId:'candidate01',adoptionId:'token-candidate01'}]})));
 expect(command.mock.calls.some(([name])=>name==='adoptWorkspaceCandidate')).toBe(false);
});
it('falls back to existing details for readonly or unavailable native project without mutation controls',()=>{
 const {w,project,command}=setup();const {rerender}=render(<WorkspaceBatchPreparation workspace={w} project={null} pending={false} command={command} onChange={vi.fn()}><p>原镜头详情</p></WorkspaceBatchPreparation>);
 expect(screen.getByText('原镜头详情')).toBeTruthy();expect(screen.queryByRole('button',{name:/批量准备/})).toBeNull();
 rerender(<WorkspaceBatchPreparation workspace={w} project={project} readOnly pending={false} command={command} onChange={vi.fn()}><p>原镜头详情</p></WorkspaceBatchPreparation>);
 expect(screen.queryByRole('button',{name:/批量准备/})).toBeNull();expect(command).not.toHaveBeenCalled();
});
it('accepts a valid decimal reservation and freezes rounded cents for each independent call',async()=>{
 const {Harness,command}=setup();render(<Harness/>);fireEvent.click(screen.getByRole('checkbox',{name:'选择镜头 01'}));fireEvent.click(screen.getByRole('button',{name:'批量准备 1'}));
 const dialog=await screen.findByRole('dialog',{name:'批量准备 · 口播'});fireEvent.change(within(dialog).getByRole('spinbutton',{name:'镜头 01 费用预留（元）'}),{target:{value:'0.29'}});
 fireEvent.click(within(dialog).getByRole('button',{name:'确认准备 1 项'}));await waitFor(()=>expect(command).toHaveBeenCalledWith('confirmWorkspaceCall',expect.objectContaining({reservationCents:29})));
});
it('scopes saved review decisions to the authenticated owner',async()=>{
 const {w,project,command}=setup(true);const view=(ownerId:string)=><WorkspaceDraftOwner ownerId={ownerId}><WorkspaceBatchPreparation workspace={w} project={project} pending={false} command={command} onChange={vi.fn()}><p>原镜头详情</p></WorkspaceBatchPreparation></WorkspaceDraftOwner>;
 const {rerender}=render(view('owner-a'));fireEvent.click(screen.getByRole('button',{name:'集中核对 2'}));fireEvent.click(screen.getByRole('button',{name:'通过并下一条'}));
 expect(screen.getByRole('button',{name:'采用已通过的 1 项'})).toBeTruthy();rerender(view('owner-b'));
 fireEvent.click(screen.getByRole('button',{name:'集中核对 2'}));expect(screen.getByRole('button',{name:'采用已通过的 0 项'})).toHaveProperty('disabled',true);
});
it('persists an uncertain accepted batch and only resumes the same confirmation payload after reopening',async()=>{
 const {Harness,command,w}=setup();const original=command.getMockImplementation()!;let confirmations=0;
 command.mockImplementation(async(name:string,data:any)=>{if(name==='confirmWorkspaceCall'&&++confirmations===1)throw Object.assign(Error('待查回执'),{code:'LOCAL_COMMAND_OUTCOME_UNKNOWN'});return original(name,data);});
 render(<Harness/>);fireEvent.click(screen.getByRole('checkbox',{name:'选择镜头 01'}));fireEvent.click(screen.getByRole('button',{name:'批量准备 1'}));
 const dialog=await screen.findByRole('dialog',{name:'批量准备 · 口播'});fireEvent.click(within(dialog).getByRole('button',{name:'确认准备 1 项'}));
 await screen.findByRole('button',{name:'核对提交结果'});const first=command.mock.calls.find(([name])=>name==='confirmWorkspaceCall')![1];cleanup();
 render(<Harness/>);expect(confirmations).toBe(1);fireEvent.click(screen.getByRole('button',{name:'核对提交结果'}));
 await waitFor(()=>expect(confirmations).toBe(2));const calls=command.mock.calls.filter(([name])=>name==='confirmWorkspaceCall');expect(calls[1][1]).toEqual(first);expect(w.revision).toBe(1);
});

it('invalidates all selected voice reviews before any token preparation when same-sha narration input changes',async()=>{
 const {Harness,command,w}=setup(true);render(<Harness/>);fireEvent.click(screen.getByRole('button',{name:'集中核对 2'}));
 fireEvent.click(screen.getByRole('button',{name:'通过并下一条'}));fireEvent.click(screen.getByRole('button',{name:'通过并下一条'}));
 const latest={...w,narration:w.narration!.map(n=>n.shotId==='02'?{...n,inputFingerprint:'changed-voice-input',voice:'another-voice',speakingRate:1.2}:n)};
 vi.stubGlobal('fetch',vi.fn(async()=>({ok:true,json:async()=>({workspace:latest})})));
 fireEvent.click(screen.getByRole('button',{name:'采用已通过的 2 项'}));
 await screen.findByText('候选或输入已变化，请重新核对。');
 expect(command.mock.calls.some(([name])=>name==='prepareWorkspaceCandidate')).toBe(false);expect(command.mock.calls.some(([name])=>name==='adoptWorkspaceBatch')).toBe(false);
});
it('checks every selected caption fingerprint against the latest workspace before preparing adoption',async()=>{
 const {w,project,command}=setup();w.captions=w.clips.map(c=>({clipId:c.id,itemId:c.itemId,shotId:c.shotId,durationMs:2000,textConfirmed:false,narrationText:c.text,alignmentInputVersion:'alignment-v1',detail:null,contract:defaultShotCaptionContract(c.text,'follow_tts'),inputFingerprint:'caption-'+c.shotId,timing:'waiting',alignmentStatus:'completed',taskId:'alignment-'+c.shotId,audioTrackId:'audio-'+c.shotId})) as ProductionWorkspace['captions'];
 const original=command.getMockImplementation()!;command.mockImplementation(async(name:string,data:any)=>name==='prepareWorkspaceCaptionAlignment'?{captionContract:w.captions!.find(c=>c.clipId===data.clipId)!.contract}:original(name,data));
 function Harness(){const[current,change]=useState(w);return <WorkspaceDraftOwner ownerId="owner"><WorkspaceBatchPreparation workspace={current} project={project} pending={false} command={command} onChange={change}><p>原详情</p></WorkspaceBatchPreparation></WorkspaceDraftOwner>;}
 render(<Harness/>);fireEvent.change(screen.getByRole('combobox',{name:'批量准备内容'}),{target:{value:'captions'}});fireEvent.click(screen.getByRole('button',{name:'集中核对 2'}));
 await waitFor(()=>expect(screen.getByRole('button',{name:'通过并下一条'})).toHaveProperty('disabled',false));fireEvent.click(screen.getByRole('button',{name:'通过并下一条'}));
 await waitFor(()=>expect(screen.getByRole('button',{name:'通过并下一条'})).toHaveProperty('disabled',false));fireEvent.click(screen.getByRole('button',{name:'通过并下一条'}));
 const previewCalls=command.mock.calls.filter(([name])=>name==='prepareWorkspaceCaptionAlignment').length;
 const latest={...w,captions:w.captions!.map(c=>c.shotId==='02'?{...c,inputFingerprint:'changed-caption'}:c)};
 vi.stubGlobal('fetch',vi.fn(async()=>({ok:true,json:async()=>({workspace:latest})})));
 fireEvent.click(screen.getByRole('button',{name:'采用已通过的 2 项'}));await screen.findByText('候选或输入已变化，请重新核对。');
 expect(command.mock.calls.filter(([name])=>name==='prepareWorkspaceCaptionAlignment')).toHaveLength(previewCalls);expect(command.mock.calls.some(([name])=>name==='adoptWorkspaceBatch')).toBe(false);
});
it('shows adoption preflight failures inside the active native review dialog',async()=>{
 const {Harness,command}=setup(true);const original=command.getMockImplementation()!;command.mockImplementation(async(name:string,data:any)=>{if(name==='prepareWorkspaceCandidate')throw Error('候选已不可用，请重新选择。');return original(name,data);});
 render(<Harness/>);fireEvent.click(screen.getByRole('button',{name:'集中核对 2'}));fireEvent.click(screen.getByRole('button',{name:'通过并下一条'}));fireEvent.click(screen.getByRole('button',{name:'采用已通过的 1 项'}));
 const dialog=screen.getByRole('dialog',{name:'集中核对 · 口播'});await waitFor(()=>expect(within(dialog).getByRole('alert').textContent).toContain('候选已不可用'));expect(command.mock.calls.some(([name])=>name==='adoptWorkspaceBatch')).toBe(false);
});
