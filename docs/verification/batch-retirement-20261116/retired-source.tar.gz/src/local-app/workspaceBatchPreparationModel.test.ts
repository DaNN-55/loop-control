// @vitest-environment jsdom
import {afterEach,expect,it,vi} from 'vitest';
import type {ProductionWorkspace} from '../productionWorkspace';
import type {OpenChatCutProject} from '../worker/openchatcutProject';
import type {WorkspaceVisualCandidate} from '../workspaceVisualCandidates';
import {batchPreparationRows,prepareWorkspaceBatchCalls,submitWorkspaceBatchCalls} from './workspaceBatchPreparationModel';
const selection={capability:'speech' as const,provider:'volcengine_tts',adapter:'volcengine_tts',model:'seed-tts-2.0',connectionVersionId:'connection'};
function workspace():ProductionWorkspace{return {id:'workspace',episodeId:'episode',revision:1,project:{sha256:'project'},stale:false,clips:['01','02'].map((id,i)=>({id:'clip-'+id,itemId:'item-'+id,shotId:id,text:'正文'+i,source:null})),narration:['01','02'].map((id,i)=>({clipId:'clip-'+id,shotId:id,mode:'tts',enabled:true,text:'正文'+i,voice:'voice',languageCode:'zh-CN',speakingRate:1,selection,status:'pending',defaults:{selection,voice:'voice',languageCode:'zh-CN',speakingRate:1},inputFingerprint:'input-'+id})),candidates:[],visualCandidates:[]} as unknown as ProductionWorkspace;}
afterEach(()=>{sessionStorage.clear();localStorage.clear();});
it('saves all voice inputs before preparing independent call proposals at the final revision, without generating',async()=>{
 let current=workspace();const commands:string[]=[];
 const command=vi.fn(async(name:string,data:any)=>{commands.push(name);if(name==='prepareWorkspaceCall'){expect(data.expectedRevision).toBe(3);return {confirmationId:data.callData.clipId,expiresAt:'2099-01-01',summary:{reservationCents:10,prompt:data.callData.clipId}};}if(name==='saveWorkspaceNarration')current={...current,revision:current.revision+1};return current;});
 const result=await prepareWorkspaceBatchCalls(current,null,'voice',['01','02'],command,()=>{});
 expect(commands).toEqual(['saveWorkspaceNarration','confirmWorkspaceNarration','saveWorkspaceNarration','confirmWorkspaceNarration','prepareWorkspaceCall','prepareWorkspaceCall']);
 expect(result.entries).toHaveLength(2);expect(result.entries[0].data).toMatchObject({confirmationId:'clip-01',expectedRevision:3});
 expect(command.mock.calls.filter(([name])=>name==='confirmWorkspaceCall')).toHaveLength(0);
});
it('does not include adopted, busy, unknown, disabled, manual or unsaved narration in new generation',()=>{
 const w=workspace();w.narration![0].adoptedAudioTrackId='adopted';expect(batchPreparationRows(w,null,'voice')[0].canPrepare).toBe(false);
 w.narration![0]={...w.narration![0],adoptedAudioTrackId:null,generationTask:{id:'t',taskId:'t',status:'running',error:null}};expect(batchPreparationRows(w,null,'voice')[0].canPrepare).toBe(false);
 w.narration![0].generationTask={id:'t',taskId:'t',status:'blocked',submissionUnknown:true,error:null};expect(batchPreparationRows(w,null,'voice')[0].state).toBe('unknown');
 w.narration![0].generationTask=undefined;w.narration![0].enabled=false;expect(batchPreparationRows(w,null,'voice')[0].canPrepare).toBe(false);
 w.narration![0].enabled=true;w.narration![0].mode='manual';expect(batchPreparationRows(w,null,'voice')[0].canPrepare).toBe(false);
 w.narration![0].mode='tts';sessionStorage.setItem('loop-speech-draft:workspace:01:text','未保存');expect(batchPreparationRows(w,null,'voice')[0].reason).toContain('草稿');
});
it('keeps per-shot image prompts and references instead of copying another shot configuration',async()=>{
 const w=workspace();w.visualConfiguration={imageSelection:{...selection,capability:'image'},imageModel:null,videoModel:null,videoProvider:null};
 w.templateInputs={version:'workspace-template-inputs/v1',narration:{},shots:w.clips.map((c,i)=>({shotId:c.shotId,imagePrompt:'图片'+i,videoPrompt:'视频'+i,narration:{},visualSource:'image'}))};
 const payloads:any[]=[];const command=vi.fn(async(_name:string,data:any)=>{payloads.push(data.callData);return {confirmationId:data.callData.targetItemId,expiresAt:'2099-01-01',summary:{reservationCents:10}};});
 await prepareWorkspaceBatchCalls(w,null,'visual',['01','02'],command,()=>{});
 expect(payloads.map(p=>p.prompt)).toEqual(['图片0','图片1']);expect(payloads.map(p=>p.targetItemId)).toEqual(['item-01','item-02']);
});
it('does not treat an untouched single-shot image tab as a choice to replace script video preparation',async()=>{
 const w=workspace();w.visualTargets=w.clips.map(c=>({targetItemId:c.itemId,durationSeconds:2,providerDurationSeconds:2,voiceMode:'none',minimumSeconds:1,maximumSeconds:10,width:1080,height:1920,defaultSelection:{...selection,capability:'video',provider:'minimax',adapter:'minimax_video',model:'MiniMax-H3-Lite'}}));
 w.templateInputs={version:'workspace-template-inputs/v1',narration:{},shots:w.clips.map((c,i)=>({shotId:c.shotId,imagePrompt:'图片'+i,videoPrompt:'视频'+i,narration:{},visualSource:'video',visual:{reference:'首帧',status:'bound',candidates:[],material:{id:'frame-'+i,name:'首帧',type:'image',purpose:'visual_reference',sha256:'a',relativePath:'frame.png',fileSize:1}}}))};
 sessionStorage.setItem('loop-visual-draft:workspace:item-01',JSON.stringify({tab:'image',origin:{image:'material',video:'material'},imagePrompt:'图片0',videoPrompt:'视频0',firstFrame:'',duration:'2'}));
 const command=vi.fn(async(_name:string,data:any)=>({confirmationId:data.callData.targetItemId,expiresAt:'2099-01-01',summary:{reservationCents:10}}));
 const result=await prepareWorkspaceBatchCalls(w,null,'visual',['01','02'],command,()=>{});
 expect(command.mock.calls.map(([,data])=>data.callCommand)).toEqual(['requestWorkspaceVisualCandidate','requestWorkspaceVisualCandidate']);expect(result.entries).toHaveLength(2);
});
it('stops on uncertain submission and resumes using the exact existing confirmation payload',async()=>{
 const w=workspace();const call={shotId:'01',command:'confirmWorkspaceCall',data:{episodeId:w.episodeId,workspaceId:w.id,expectedRevision:1,confirmationId:'frozen',reservationCents:10},status:'waiting' as const};
 const plan={kind:'voice' as const,workspaceId:w.id,episodeId:w.episodeId,projectSha256:'project',entries:[call,{...call,shotId:'02',data:{...call.data,confirmationId:'second'}}]};
 const failed=vi.fn(async()=>{throw Object.assign(Error('unknown'),{code:'LOCAL_COMMAND_OUTCOME_UNKNOWN'});});const persist=vi.fn();
 const first=await submitWorkspaceBatchCalls(plan,w,failed,()=>{},persist);
 expect(first.entries[0].status).toBe('unknown');expect(first.entries[1].status).toBe('waiting');expect(failed).toHaveBeenCalledTimes(1);
 const ok=vi.fn(async(_command:string,_data:unknown)=>w);await submitWorkspaceBatchCalls(first,w,ok,()=>{},persist);
 expect(ok.mock.calls[0][1]).toEqual(call.data);expect(ok).toHaveBeenCalledTimes(2);
});
it('only prepares captions for an enabled lane with adopted audio and keeps its fingerprint',async()=>{
 const w=workspace();w.narration![0].adoptedAudioTrackId='track';w.captions=[{clipId:'clip-01',shotId:'01',itemId:'item-01',contract:{enabled:true},audioTrackId:'track',inputFingerprint:'caption-1',timing:'missing'},{clipId:'clip-02',shotId:'02',itemId:'item-02',contract:{enabled:true},audioTrackId:null,inputFingerprint:'caption-2',timing:'missing'}] as ProductionWorkspace['captions'];
 expect(batchPreparationRows(w,null,'captions').map(r=>r.canPrepare)).toEqual([true,false]);
 const plan=await prepareWorkspaceBatchCalls(w,null,'captions',['01'],vi.fn(),()=>{});expect(plan.entries[0].data).toMatchObject({clipId:'clip-01',localOnly:true});
});

it('unwraps the actual caption command response before publishing and continuing the batch',async()=>{
 const w=workspace();const next={...w,revision:2};const publish=vi.fn();
 const plan={kind:'captions' as const,workspaceId:w.id,episodeId:w.episodeId,projectSha256:w.project.sha256,entries:['01','02'].map(id=>({shotId:id,command:'requestWorkspaceCaptionAlignment',data:{workspaceId:w.id,expectedRevision:1,clipId:'clip-'+id,localOnly:true},status:'waiting' as const}))};
 const command=vi.fn(async()=>({workspace:next,task:{id:'alignment-task'}}));
 const result=await submitWorkspaceBatchCalls(plan,w,command,publish,()=>{});
 expect(result.entries.map(e=>e.status)).toEqual(['submitted','submitted']);expect(publish).toHaveBeenCalledWith(next);expect(command).toHaveBeenCalledTimes(2);
});

it('uses the current native visual even when original bindings have no source, and never treats historical adoption as current',()=>{
 const w=workspace(),sha='a'.repeat(64),clip=w.clips[0];
 const candidate:WorkspaceVisualCandidate={id:'video-candidate',kind:'video',clipId:clip.id,shotId:clip.shotId,targetItemId:clip.itemId,taskId:'task',inputFingerprint:'input',text:'视频提示',mainScriptText:clip.text,audioTrackId:null,relativePath:'generated/video.mp4',sha256:sha,fileSize:100,durationSeconds:2,status:'adopted',currentDurationSeconds:2,usage:'video',width:1080,height:1920};
 w.visualCandidates=[candidate];w.visualTargets=[{targetItemId:clip.itemId,durationSeconds:2,providerDurationSeconds:2,voiceMode:'none',minimumSeconds:1,maximumSeconds:10,width:1080,height:1920,defaultSelection:{...selection,capability:'video',provider:'minimax',adapter:'minimax_video',model:'MiniMax-H3-Lite'}}];
 w.templateInputs={version:'workspace-template-inputs/v1',narration:{},shots:[{shotId:clip.shotId,imagePrompt:'图片',videoPrompt:'视频提示',narration:{},visualSource:'video',visual:{reference:'首帧',status:'bound',candidates:[],material:{id:'frame',name:'首帧',type:'image',purpose:'visual_reference',sha256:'b'.repeat(64),relativePath:'frame.png',fileSize:10}}}]};
 const project:OpenChatCutProject={version:3,activeTimelineId:'timeline',assets:[],mediaFolders:[],timelines:[{id:'timeline',name:'当前工程',order:0,fps:30,width:1080,height:1920,fit:'contain',trackOrder:[],tracks:{},transitions:[],selectedId:null,captionsHidden:false,items:[{id:clip.itemId,kind:'video',src:candidate.relativePath,sourceContentHash:sha,startFrame:0,durationInFrames:60}]}]};
 const adopted=batchPreparationRows(w,project,'visual')[0];expect(clip.source).toBeNull();expect(adopted.state).toBe('adopted');expect(adopted.canPrepare).toBe(false);
 // The decision remains historical after this visual is cleared in the native editor.
 project.timelines[0].items[0]={id:clip.itemId,kind:'text',startFrame:0,durationInFrames:60};
 w.clips[0].source={materialRevisionId:'old',kind:'video',relativePath:candidate.relativePath,sha256:sha,fileSize:100};
 const cleared=batchPreparationRows(w,project,'visual')[0];expect(cleared.state).toBe('empty');expect(cleared.canPrepare).toBe(true);
});
