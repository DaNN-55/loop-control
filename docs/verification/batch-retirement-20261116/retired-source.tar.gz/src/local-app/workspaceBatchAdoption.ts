import type {PoolClient} from 'pg';
import type {WorkspaceBatchKind,WorkspaceBatchCandidateAdoption,WorkspaceBatchCaptionAdoption} from '../workspaceBatch.js';
import {applyWorkspaceCandidate,isWorkspaceCandidateEdit,type WorkspaceCandidate} from '../workspaceCandidates.js';
import type {OpenChatCutProject} from '../worker/openchatcutProject.js';
import type {ShotCaptionContract} from '../shotCaptions.js';
import {readWorkspaceCandidates} from './workspaceCandidates.js';
import {readWorkspaceVisualCandidates} from './workspaceVisualCandidates.js';
import {readWorkspaceNarration} from './workspaceNarration.js';
import {recordWorkspaceCandidateDecision} from './workspaceCandidateAdoption.js';
import {executeWorkspaceCaptionCommand,applyPreparedWorkspaceCaptionAlignment} from './workspaceCaptionsCommands.js';
import {persistWorkspaceRevision,readProductionWorkspace,type ProductionWorkspaceRecord} from './productionWorkspaceCommands.js';
import {verifyEpisodeFile} from './episodeFiles.js';
import {requireWritableEpisodeStorage} from './episodeStorageLocation.js';
import {isOpenChatCutStudio} from '../worker/openchatcutStudio.js';
import {ConfigurationError} from './configurationCommands.js';

const uuid=(value:unknown):value is string=>typeof value==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(value);
const conflict=(message='批量采用依据已变化，请重新核对当前候选。')=>new ConfigurationError(409,message);
/** The caller holds the episode/Owner transaction and current workspace row lock. */
export async function adoptWorkspaceBatch(c:PoolClient,root:string,row:ProductionWorkspaceRecord,project:OpenChatCutProject,data:Record<string,unknown>){
 if(typeof data.kind!=='string'||!['voice','visual','captions'].includes(data.kind)||typeof data.expectedProjectSha256!=='string'||!/^[a-f0-9]{64}$/.test(data.expectedProjectSha256)||!Array.isArray(data.items)||!data.items.length||data.items.length>row.bindings.length)throw new ConfigurationError(400,'请选择有效的批量采用范围。');
 if(data.expectedProjectSha256!==row.project_sha256)throw conflict('工程已变化，请重新核对批量采用影响。');
 if(isOpenChatCutStudio(row.episode_id))throw conflict('请先保存并退出剪辑工作台，再批量采用。');
 await requireWritableEpisodeStorage(c,root,row.episode_id);
 const kind=data.kind as WorkspaceBatchKind,items=data.items as Record<string,unknown>[];
 if(items.some(item=>!item||typeof item!=='object'||Array.isArray(item)))throw new ConfigurationError(400,'批量采用条目无效。');
 const keys=kind==='captions'?['clipId','taskId','expectedInputFingerprint']:['candidateId','adoptionId'];
 if(items.some(item=>Object.keys(item).some(key=>!keys.includes(key))||keys.some(key=>key==='expectedInputFingerprint'?typeof item[key]!=='string'||!/^[a-f0-9]{64}$/.test(item[key] as string):!uuid(item[key]))))throw new ConfigurationError(400,'批量采用条目无效。');
 const identities=items.map(item=>String(kind==='captions'?item.clipId:item.candidateId));
 if(new Set(identities).size!==items.length)throw new ConfigurationError(400,'同一候选或镜头不能重复采用。');
 let next=structuredClone(project);
 if(kind==='captions'){
  const prepared:Array<{clipId:string;taskId:string;contract:ShotCaptionContract}>=[],shots=new Set<string>();
  // Prepare every result against the original project before writing any evidence.
  for(const item of items as unknown as WorkspaceBatchCaptionAdoption[]){
   const clip=row.bindings.find(binding=>binding.id===item.clipId);
   if(!clip)throw conflict('字幕镜头不属于当前工程。');
   if(shots.has(clip.shotId))throw new ConfigurationError(400,'同一镜头不能重复采用。');shots.add(clip.shotId);
   const result=await executeWorkspaceCaptionCommand(c,root,row,project,{},'prepareWorkspaceCaptionAlignment',item as unknown as Record<string,unknown>) as {captionContract:ShotCaptionContract};
   prepared.push({clipId:item.clipId,taskId:item.taskId,contract:result.captionContract});
  }
  for(const item of prepared)next=await applyPreparedWorkspaceCaptionAlignment(c,root,row,next,item.clipId,item.taskId,item.contract);
  await persistWorkspaceRevision(c,root,row,next,row.bindings,'批量采用字幕对齐',{nativeEdit:true});
 }else{
  const candidates=kind==='voice'?await readWorkspaceCandidates(c,row,project):await readWorkspaceVisualCandidates(c,row,project,root);
  const narrations=kind==='voice'?await readWorkspaceNarration(c,row,project):[];
  const prepared:Array<{candidate:WorkspaceCandidate;edit:NonNullable<Parameters<typeof applyWorkspaceCandidate>[1]>}>=[],shots=new Set<string>();
  for(const item of items as unknown as WorkspaceBatchCandidateAdoption[]){
   const candidate=candidates.find(candidate=>candidate.id===item.candidateId);
   if(!candidate||candidate.status!=='available'||kind==='voice'&&candidate.kind!=='audio'||kind==='visual'&&candidate.kind==='audio')throw conflict();
   if(shots.has(candidate.shotId))throw new ConfigurationError(400,'同一镜头不能重复采用。');shots.add(candidate.shotId);
   if(kind==='voice'&&narrations.find(n=>n.shotId===candidate.shotId)?.enabled===false)throw conflict('镜头口播已关闭，请重新核对。');
   const saved=(await c.query('SELECT * FROM local_identity.workspace_candidate_adoptions WHERE id=$1 AND workspace_id=$2 AND candidate_id=$3',[item.adoptionId,row.id,candidate.id])).rows[0];
   if(!saved||saved.project_sha256!==row.project_sha256||saved.input_fingerprint!==candidate.inputFingerprint||saved.edit?.restoreFingerprint!==undefined)throw conflict();
   let registeredSoundPath:string|undefined;
   if(saved.edit?.videoSound?.mode==='separate'){
    const sound=saved.edit.videoSound,materialId=typeof sound.asset?.id==='string'&&sound.asset.id.startsWith('material-')?sound.asset.id.slice(9):null;
    if(!uuid(materialId))throw conflict('视频原声音轨的素材身份无效，请重新核对。');
    const material=(await c.query("SELECT storage_path,sha256,file_size FROM public.production_material_revisions WHERE id=$1 AND episode_id=$2 AND material_type='audio'",[materialId,row.episode_id])).rows[0];
    if(!material||sound.asset.src!==material.storage_path||sound.sha256!==material.sha256)throw conflict('视频原声音轨的注册来源已变化，请重新核对。');
    await verifyEpisodeFile(c,root,row.episode_id,material.storage_path,material.sha256,Number(material.file_size));
    registeredSoundPath=material.storage_path;
   }
   // Stored edits use episode material paths; native IPC keeps its default SDK-only path contract.
   if(!isWorkspaceCandidateEdit(saved.edit,src=>registeredSoundPath!==undefined&&src===registeredSoundPath))throw conflict();
   if(kind==='voice'&&(!saved.edit.reviewNarrationFingerprint||saved.edit.reviewNarrationFingerprint!==narrations.find(n=>n.shotId===candidate.shotId)?.inputFingerprint))throw conflict('口播输入已变化，请重新核对本批候选。');
   const edit=saved.edit;
   if(edit.source.sha256!==candidate.sha256||edit.source.src!==candidate.relativePath||edit.source.inputFingerprint!==candidate.inputFingerprint||edit.targetItemId!==candidate.targetItemId)throw conflict();
   await verifyEpisodeFile(c,root,row.episode_id,candidate.relativePath,candidate.sha256,candidate.fileSize);
   prepared.push({candidate,edit});
  }
  // Applying disjoint shots preserves each prepared target and route; no intermediate project is persisted.
  for(const {edit} of prepared)try{next=applyWorkspaceCandidate(next,edit);}catch(error){throw conflict(error instanceof Error?error.message:undefined);}
  const current=await persistWorkspaceRevision(c,root,row,next,row.bindings,kind==='voice'?'批量采用口播候选':'批量采用画面候选',{nativeEdit:true});
  for(const {candidate} of prepared){
   await recordWorkspaceCandidateDecision(c,current,candidate,'adopted');
   if(kind==='voice')await c.query('UPDATE local_identity.workspace_narrations SET adopted_audio_track_id=$3 WHERE workspace_id=$1 AND shot_id=$2',[row.id,candidate.shotId,candidate.audioTrackId]);
  }
 }
 return readProductionWorkspace(c,row.episode_id,root);
}
