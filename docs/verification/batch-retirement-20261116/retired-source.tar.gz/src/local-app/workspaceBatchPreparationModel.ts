import type {ProductionWorkspace,WorkspaceNarration} from '../productionWorkspace';
import type {OpenChatCutProject} from '../worker/openchatcutProject';
import type {WorkspaceCallProposal} from '../workspaceCall';
import type {WorkspaceCandidate} from '../workspaceCandidates';
import type {WorkspaceBatchKind} from '../workspaceBatch';
import type {ProductionService} from '../connections/serviceCatalog';
import type {ProductionSelection} from '../productionSelection';
import type {ImageBrief,ImageGenerationSettings} from '../imageGeneration';
import {emptyImageBrief,imageSizePresets} from '../imageGeneration';
import {defaultWanSettings,type WanGenerationSettings} from '../videoGenerationSettings';
import {defaultWanModelSettings} from '../wanVideoModels';
import {firstFrameVideoMode} from '../worker/registeredAdapters';
import {readWorkspaceShotWindow} from '../workspaceShots';
import {workspaceTaskPresentation} from '../workspaceTaskPresentation';
import {resolveVideoInputs,type VideoInputDraft,type VideoInputMaterial} from './WorkspaceVideoInputs';
import {workspaceShotSource} from './WorkspaceShotPreview';
import type {PromptReferenceBinding} from '../promptReferences';

export type BatchRowState='empty'|'ready'|'adopted'|'running'|'failed'|'unknown'|'disabled';
export interface BatchPreparationRow {shotId:string;clipId:string;itemId:string;text:string;durationSeconds:number|null;state:BatchRowState;reason:string;canPrepare:boolean;candidates:WorkspaceCandidate[];taskId?:string;}
export interface BatchCallEntry {shotId:string;command:string;data:Record<string,unknown>;proposal?:WorkspaceCallProposal;status:'waiting'|'submitting'|'submitted'|'failed'|'unknown';error?:string;}
export interface BatchCallPlan {accepted?:boolean;kind:WorkspaceBatchKind;workspaceId:string;episodeId:string;projectSha256:string;entries:BatchCallEntry[];}
export type BatchCommand=(name:string,data:unknown)=>Promise<unknown>;
export interface BatchVisualContext {materials?:VideoInputMaterial[];services?:ProductionService[];}
interface VisualDraft {tab?:'image'|'video';origin?:{image?:string;video?:string};imageSelection?:ProductionSelection|null;videoSelection?:ProductionSelection|null;imagePrompt?:string;videoPrompt?:string;references?:string[];firstFrame?:string;videoInputIds?:string[];videoInputs?:VideoInputDraft;videoModeId?:string;referenceVideoSources?:Record<string,string>;videoSettings?:WanGenerationSettings;videoResolution?:string;firstFrameFit?:'contain'|'cover';duration?:string;settings?:ImageGenerationSettings;imageBrief?:ImageBrief;promptReferences?:PromptReferenceBinding[];}
function draft<T>(key:string):Partial<T>{try{const value=JSON.parse(sessionStorage.getItem(key)??'null');return value&&typeof value==='object'&&!Array.isArray(value)?value:{};}catch{return{};}}
function speechSettings(w:ProductionWorkspace,n:WorkspaceNarration){
 const shared=w.narration?.find(v=>v.defaults)?.defaults,template=w.templateInputs?.shots.find(s=>s.shotId===n.shotId)?.narration??w.templateInputs?.narration;
 return shared??{selection:n.selection,voice:n.voice??template?.voice??'',languageCode:n.languageCode??template?.languageCode??'zh-CN',speakingRate:n.speakingRate??template?.speakingRate??1};
}
function voiceDraftProblem(w:ProductionWorkspace,n:WorkspaceNarration){
 try{const text=sessionStorage.getItem(`loop-speech-draft:${w.id}:${n.shotId}:text`),mode=sessionStorage.getItem(`loop-speech-draft:${w.id}:${n.shotId}:mode`);if(text!==null&&text!==n.text||mode&&mode!=='tts')return '有未处理的口播草稿，请先在详情核对。';}catch{/* Server inputs remain authoritative. */}
 return '';
}
function visualRequest(w:ProductionWorkspace,project:OpenChatCutProject|null,shotId:string,context:BatchVisualContext={}){
 const clip=w.clips.find(c=>c.shotId===shotId)!;
 const template=w.templateInputs?.shots.find(s=>s.shotId===shotId),target=w.visualTargets?.find(t=>t.targetItemId===clip.itemId);
 const stored=draft<VisualDraft>(`loop-visual-draft:${w.id}:${clip.itemId}`),defaults={...draft<VisualDraft>(`loop-image-default:${w.id}`),...draft<VisualDraft>(`loop-video-default:${w.id}`)},d={...defaults,...stored};
 const explicit=stored.tab&&stored.origin?.[stored.tab]==='generate'?stored.tab:undefined;
 const kind=explicit??(template?.visualSource==='image'?'image':template?.visualSource==='video'?'video':d.tab??'video');
 if(!explicit&&(template?.visualSource==='material'||stored.origin?.[kind]==='search'))throw Error('当前镜头选择上传或检索来源，请在详情准备素材。');
 const selection=kind==='image'?d.imageSelection??w.visualConfiguration?.imageSelection:d.videoSelection??target?.defaultSelection;
 if(!selection?.model)throw Error('请先选择本单画面连接与模型。');
 const prompt=kind==='image'?d.imagePrompt??template?.imagePrompt:d.videoPrompt??template?.videoPrompt;
 if(typeof prompt!=='string'||!prompt.trim())throw Error('请先填写本镜头画面提示词。');
 const data:Record<string,unknown>={targetItemId:clip.itemId,selection,prompt,...(d.promptReferences?{promptReferences:d.promptReferences}:{})};
 if(kind==='image'){
  const ratio=(target?.width??9)/(target?.height??16),size=[...imageSizePresets].sort((a,b)=>Math.abs(Number(a.ratio.split(':')[0])/Number(a.ratio.split(':')[1])-ratio)-Math.abs(Number(b.ratio.split(':')[0])/Number(b.ratio.split(':')[1])-ratio))[0].standard;
  const references=d.references??[],brief=d.imageBrief??emptyImageBrief;
  Object.assign(data,{settings:d.settings??{size,quality:'auto',count:1},referenceMaterialRevisionIds:references,imageBrief:{...brief,references:references.map(id=>brief.references.find(r=>r.materialRevisionId===id)??{materialRevisionId:id,purpose:'subject',preserve:'',change:''})}});
  return{command:'requestWorkspaceImageCandidates',data};
 }
 const window=project?readWorkspaceShotWindow(project,clip.itemId):undefined;
 const duration=target?.voiceMode&&target.voiceMode!=='none'?target.durationSeconds:Number(d.duration??target?.durationSeconds??(window?window.durationInFrames/window.timeline.fps:NaN));
 if(!duration||!Number.isFinite(duration)||duration<=0)throw Error('请先采用本镜头声音或设置有效画面时长。');
 const service=context.services?.find(s=>s.capability==='video'&&s.connectionVersionId===selection.connectionVersionId&&s.provider===selection.provider&&s.adapter===selection.adapter);
 const modes=service?.videoGenerationModes?.[selection.model]??[firstFrameVideoMode()];
 const mode=modes.find(m=>m.id===d.videoModeId)??modes[0];
 if(d.videoModeId&&!modes.some(m=>m.id===d.videoModeId))throw Error('当前画面输入模式已变化，请在详情核对。');
 const first=d.firstFrame||w.selectedImages?.find(s=>s.targetItemId===clip.itemId)?.materialRevisionId||(template?.visual?.status==='bound'&&template.visual.material?.type==='image'?template.visual.material.id:undefined);
 const ids=d.videoInputIds??[first,...d.videoInputs?.lastFrame??[],...d.videoInputs?.referenceImages??[],...d.videoInputs?.referenceVideos??[]].filter((id):id is string=>!!id);
 if(mode.id==='first-frame'){
  if(!ids[0])throw Error('请先为本镜头选择视频首帧。');
  Object.assign(data,{firstFrameMaterialRevisionId:ids[0],firstFrameFit:d.firstFrameFit??'contain'});
 }else{
  const entries=resolveVideoInputs(mode,ids,context.materials??[]);
  if(entries.some(e=>e.reason))throw Error('参考素材与当前模式不兼容，请在详情核对。');
  Object.assign(data,{videoMode:mode.id,visualInputs:entries.flatMap(e=>e.role?[{role:e.role,materialRevisionId:e.id,...(d.referenceVideoSources?.[e.id]?{source:d.referenceVideoSources[e.id]}:{})}]:[]),...(entries.some(e=>e.role==='firstFrame')?{firstFrameFit:d.firstFrameFit??'contain'}:{})});
 }
 Object.assign(data,{durationSeconds:duration,...(selection.provider==='bailian'?{videoSettings:d.videoSettings??defaultWanModelSettings(selection.model)}:selection.provider==='minimax'?{videoResolution:d.videoResolution??'768P'}:{})});
 if(selection.provider!=='bailian'&&d.videoSettings&&JSON.stringify(d.videoSettings)!==JSON.stringify(defaultWanSettings))throw Error('当前模型与已保存的视频参数不兼容，请在详情核对。');
 return{command:'requestWorkspaceVisualCandidate',data};
}
export function batchPreparationRows(w:ProductionWorkspace,project:OpenChatCutProject|null,kind:WorkspaceBatchKind,context:BatchVisualContext={}):BatchPreparationRow[]{
 return w.clips.filter((c,i,all)=>all.findIndex(s=>s.shotId===c.shotId)===i).map(clip=>{
  const n=w.narration?.find(v=>v.shotId===clip.shotId),caption=w.captions?.find(c=>c.shotId===clip.shotId),window=project?readWorkspaceShotWindow(project,clip.itemId):undefined;
  const candidates=kind==='voice'?(w.candidates??[]).filter(c=>c.shotId===clip.shotId&&c.kind==='audio'&&c.status==='available'):(w.visualCandidates??[]).filter(c=>c.targetItemId===clip.itemId&&c.status==='available');
  const tasks=kind==='voice'?[n?.generationTask]:kind==='visual'?(w.visualTasks??[]).filter(t=>t.shotId===clip.shotId||t.targetItemId===clip.itemId):[];
  const relevant=tasks.filter(t=>t&&!t.retryTaskId),unknown=relevant.find(t=>t&&workspaceTaskPresentation(t).unknown),held=relevant.find(t=>t&&workspaceTaskPresentation(t).held),busy=relevant.find(t=>t&&workspaceTaskPresentation(t).active),failed=relevant.find(t=>t&&workspaceTaskPresentation(t).stopped);
  let state:BatchRowState='empty',reason='';
  if(unknown||held){state='unknown';reason=held?'结果发布待核对，请先在详情恢复。':'提交结果未知，请先核对原请求回执。';}
  else if(busy){state='running';reason='已有任务处理中。';}
  else if(kind==='captions'){
   if(!caption?.contract.enabled){state='disabled';reason='字幕已关闭。';}
   else if(caption.timing==='waiting'&&caption.alignmentStatus==='completed')state='ready';
   else if(caption.timing==='waiting'){state='running';reason='字幕对齐处理中。';}
   else if(caption.timing==='current')state='adopted';
   else if(!caption.audioTrackId){state='disabled';reason='先采用本镜头声音，再对齐字幕。';}
   else if(caption.timing==='failed')state='failed';
  }else if(candidates.length)state='ready';
  else if(kind==='voice'&&(n?.adoptedAudioTrackId||w.usedNarration?.some(v=>v.shotId===clip.shotId))||kind==='visual'&&workspaceShotSource(clip,project))state='adopted';
  else if(kind==='voice'){
   if(!n||n.enabled===false||n.mode==='none'&&n.enabled!==true){state='disabled';reason='口播已关闭。';}
   else if(n.mode==='manual'){state='disabled';reason='当前镜头使用人工口播。';}
   else if(voiceDraftProblem(w,n)){state='disabled';reason=voiceDraftProblem(w,n);}
   else{const settings=speechSettings(w,n);if(!settings.selection||!settings.voice){state='disabled';reason='请先选择本单口播模型和声音。';}else if(failed||n.status==='failed')state='failed';}
  }else if(failed)state='failed';
  if(kind==='visual'&&(state==='empty'||state==='failed'))try{visualRequest(w,project,clip.shotId,context);}catch(error){state='disabled';reason=error instanceof Error?error.message:'画面输入未齐备。';}
  return{shotId:clip.shotId,clipId:clip.id,itemId:clip.itemId,text:clip.text,durationSeconds:window?window.durationInFrames/window.timeline.fps:n?.durationSeconds??null,state,reason,canPrepare:!w.stale&&(state==='empty'||state==='failed'),candidates:kind==='captions'?[]:candidates,taskId:(unknown??held??busy??failed)?.taskId??(kind==='captions'?caption?.taskId??undefined:undefined)};
 });
}
export async function prepareWorkspaceBatchCalls(w:ProductionWorkspace,project:OpenChatCutProject|null,kind:WorkspaceBatchKind,shotIds:string[],command:BatchCommand,publish:(w:ProductionWorkspace)=>void,context:BatchVisualContext={},owns=()=>true):Promise<BatchCallPlan>{
 const rows=batchPreparationRows(w,project,kind,context).filter(row=>shotIds.includes(row.shotId)&&row.canPrepare);
 if(!rows.length)throw Error('所选镜头没有可准备的项目。');
 let current=w;
 const base=(clipId?:string)=>({episodeId:w.episodeId,workspaceId:w.id,expectedRevision:current.revision,...(clipId?{clipId}:{})});
 if(kind==='voice')for(const row of rows){
  if(!owns())throw Object.assign(Error(''),{name:'AbortError'});
  const n=current.narration!.find(n=>n.shotId===row.shotId)!;
  current=await command('saveWorkspaceNarration',{...base(row.clipId),mode:'tts',text:n.text,...speechSettings(current,n)}) as ProductionWorkspace;publish(current);
  if(!owns())throw Object.assign(Error(''),{name:'AbortError'});
  current=await command('confirmWorkspaceNarration',base(row.clipId)) as ProductionWorkspace;publish(current);
 }
 const entries:BatchCallEntry[]=[];
 for(const row of rows){
  if(!owns())throw Object.assign(Error(''),{name:'AbortError'});
  if(kind==='captions'){entries.push({shotId:row.shotId,command:'requestWorkspaceCaptionAlignment',data:{...base(row.clipId),localOnly:true},status:'waiting'});continue;}
  const call=kind==='voice'?{command:'generateWorkspaceNarration',data:{...base(row.clipId),retry:current.narration?.find(n=>n.shotId===row.shotId)?.status==='failed'}}:visualRequest(current,project,row.shotId,context);
  const callData={...base(),...call.data};
  const proposal=await command('prepareWorkspaceCall',{...base(),callCommand:call.command,callData}) as WorkspaceCallProposal;
  entries.push({shotId:row.shotId,command:'confirmWorkspaceCall',data:{...base(),confirmationId:proposal.confirmationId,reservationCents:proposal.summary.reservationCents},proposal,status:'waiting'});
 }
 return{kind,workspaceId:w.id,episodeId:w.episodeId,projectSha256:current.project.sha256,entries};
}
export async function submitWorkspaceBatchCalls(plan:BatchCallPlan,current:ProductionWorkspace,command:BatchCommand,publish:(w:ProductionWorkspace)=>void,persist:(plan:BatchCallPlan)=>void,owns=()=>true):Promise<BatchCallPlan>{
 let next:BatchCallPlan={...plan,entries:plan.entries.map(e=>({...e,data:{...e.data}}))};
 if(next.workspaceId!==current.id||next.episodeId!==current.episodeId)throw Error('工程已切换，请重新核对。');
 for(let index=0;index<next.entries.length;index++){
  const entry=next.entries[index];if(entry.status==='submitted')continue;
  if(!owns())break;
  // An uncertain call keeps its exact payload so localCommand reads the old receipt.
  if(entry.status!=='unknown'&&entry.status!=='submitting'&&current.project.sha256!==plan.projectSha256)throw Error('工程已变化，未提交项目已停止，请重新核对。');
  entry.status='submitting';delete entry.error;persist({...next,entries:next.entries.map(e=>({...e}))});
  try{
   const result=await command(entry.command,entry.data);
   const updated=entry.command==='requestWorkspaceCaptionAlignment'?(result as {workspace:ProductionWorkspace}).workspace:result as ProductionWorkspace;
   current=updated;publish(updated);entry.status='submitted';persist({...next,entries:next.entries.map(e=>({...e}))});
  }catch(error){entry.status=['LOCAL_COMMAND_OUTCOME_UNKNOWN','local_service_unavailable'].includes((error as {code?:string})?.code??'')?'unknown':'failed';entry.error=error instanceof Error?error.message:'提交未完成。';persist({...next,entries:next.entries.map(e=>({...e}))});break;}
 }
 return{...next,entries:next.entries.map(e=>({...e}))};
}
export function batchCandidateIdentity(w:ProductionWorkspace,kind:WorkspaceBatchKind,shotId:string,candidateId:string){
 if(kind==='captions'){const c=w.captions?.find(c=>c.shotId===shotId);return JSON.stringify([w.id,w.project.sha256,kind,shotId,c?.taskId,c?.inputFingerprint,c?.alignmentStatus,c?.contract.enabled,c?.audioTrackId]);}
 const c=(kind==='voice'?w.candidates:w.visualCandidates)?.find(c=>c.id===candidateId);
 const narration=kind==='voice'?w.narration?.find(n=>n.shotId===shotId):undefined;
 return JSON.stringify([w.id,w.project.sha256,kind,shotId,c?.id,c?.sha256,c?.inputFingerprint,c?.status,...(kind==='voice'?[narration?.inputFingerprint,narration?.enabled??narration?.mode!=='none',narration?.mode]:[])]);
}
