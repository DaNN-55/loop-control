import {scriptSegments} from '../data.js';

const $ = selector => document.querySelector(selector);
const asset = name => `../assets/${name}`;
const key = 'loop-control:batch-flow-demo:v1';
const kinds = {voice:'口播', visual:'画面', captions:'字幕'};
const labels = {empty:'待准备', queued:'排队中', running:'准备中', ready:'待核对', adopted:'已采用', failed:'失败', unknown:'结果未知'};
const durations = [3.07,5.67,6.7,5.67,5.1,3.46];
const starts = [0,3.07,8.74,15.44,21.11,26.21];
const defaults = {
  voice:{model:'seed-tts-2.0',voice:'明亮女声',rate:'1'},
  visual:{model:'MiniMax-H3-Lite',resolution:'768P'},
  captions:{lines:'2',chars:'14'}
};
const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const number = i => String(i+1).padStart(2,'0');
let state = load();
let selected = new Set();
let filter = 'all';
let mode = '';
let reviewIds = [];
let activeId = 0;
let confirmationAction = null;
let commitBusy = false;
let toastTimer;

function fresh(scenario='start') {
  const result = {version:1,scenario,kind:scenario==='exceptions'?'visual':'voice',settings:{voice:{},visual:{},captions:{}},events:[],sequence:0,shots:scriptSegments.map((_,i)=>({voice:{status:'empty'},visual:{status:'empty'},captions:{status:'empty'}}))};
  if(scenario!=='start') {
    result.shots.forEach(s=>{
      s.voice={status:scenario==='exceptions'?'adopted':'ready',reviewed:false};
      s.visual={status:'ready',reviewed:false};
    });
  }
  if(scenario==='exceptions') {
    result.shots[0].visual.warning='墙面出现脚本未要求的挂画，请检查示例旧候选。';
    result.shots[2].visual={status:'failed',message:'供应商暂时繁忙，本次已明确失败。可单独重试。'};
    result.shots[3].visual={status:'adopted'};
    result.shots[4].visual={status:'unknown',message:'请求已发出但回执中断，先查询原请求，不能再次生成。'};
  }
  return result;
}
function load() {
  try {const saved=JSON.parse(localStorage.getItem(key));if(saved?.version===1&&saved.shots?.length===6)return saved;} catch {/* Demo storage is optional. */}
  return fresh();
}
function persist(){try{localStorage.setItem(key,JSON.stringify(state));}catch{/* Keep the demo usable without storage. */}}
function entry(i,kind=state.kind){return state.shots[i][kind];}
function log(text,detail=''){state.events.unshift({text,detail,time:new Date().toLocaleTimeString('zh-CN',{hour12:false})});state.events=state.events.slice(0,40);persist();}
function toast(message){clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').classList.add('show');toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),4500);}
function effective(kind=state.kind){return {...defaults[kind],...state.settings[kind]};}
function configLabel(kind,config=effective(kind)) {
  if(kind==='voice')return `${config.model} · ${config.voice} · ${config.rate}×`;
  if(kind==='visual')return `${config.model} · ${config.resolution} · 各镜头独立提示词与首帧`;
  return `最多 ${config.lines} 行 · 每行 ${config.chars} 字`;
}
function eligible(i,kind=state.kind){const s=entry(i,kind).status;return (s==='empty'||s==='failed')&&(kind!=='captions'||entry(i,'voice').status==='adopted');}
function scopedIds(){return selected.size?[...selected]:state.shots.map((_,i)=>i);}
function prepareIds(){return scopedIds().filter(i=>eligible(i));}
function readyIds(){return scopedIds().filter(i=>entry(i).status==='ready');}
function visibleIds(){return state.shots.map((_,i)=>i).filter(i=>filter==='all'||(filter==='issues'?['failed','unknown'].includes(entry(i).status)||!!entry(i).warning:entry(i).status===filter));}
function statusButton(i,kind){const s=entry(i,kind);return `<button class="status-button ${s.status} ${s.warning?'attention':''}" data-inspect="${i}" data-inspect-kind="${kind}" aria-label="${number(i)} ${kinds[kind]}：${s.warning?'待检查':labels[s.status]}">${s.status==='adopted'?'✓ ':s.warning?'! ':''}${s.warning?'待检查':labels[s.status]}</button>`;}
function renderMain(){
  const focusId=document.activeElement?.id;
  const ready=state.shots.filter(s=>s[state.kind].status==='ready').length;
  const issues=state.shots.filter(s=>['failed','unknown'].includes(s[state.kind].status)||s[state.kind].warning).length;
  const adopted=state.shots.filter(s=>s[state.kind].status==='adopted').length;
  const totalAdopted=state.shots.reduce((sum,s)=>sum+Object.keys(kinds).filter(k=>s[k].status==='adopted').length,0);
  $('#scenario').value=state.scenario;
  document.querySelectorAll('[data-kind]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.kind===state.kind)));
  document.querySelectorAll('[data-filter]').forEach(b=>{b.setAttribute('aria-pressed',String(b.dataset.filter===filter));b.textContent=({all:'全部 6',ready:`待核对 ${ready}`,issues:`需处理 ${issues}`,adopted:`已采用 ${adopted}`})[b.dataset.filter];});
  $('#settingsSummary').textContent=configLabel(state.kind);
  $('#selectionInfo').textContent=selected.size?`已选择 ${selected.size} 个镜头`:`未选择镜头，将处理本单待准备${kinds[state.kind]}`;
  $('#clearSelection').hidden=!selected.size;
  const prep=prepareIds(),review=readyIds();
  $('#prepare').textContent=`批量准备${prep.length?` ${prep.length}`:''}`;$('#prepare').disabled=!prep.length;
  $('#review').textContent=`集中核对${review.length?` ${review.length}`:''}`;$('#review').disabled=!review.length;
  $('#overall').textContent=`${totalAdopted} / 18 项已采用`;
  $('#orderState').textContent=totalAdopted===18?'✓ 素材已就绪':'制作中';
  $('#adoptedSummary').textContent=`当前${kinds[state.kind]}：${adopted} 已采用 · ${ready} 待核对${issues?` · ${issues} 需处理`:''}`;
  $('#nextStep').textContent=state.kind==='captions'&&state.shots.some(s=>s.voice.status!=='adopted')?'字幕按已采用口播对齐；其余镜头采用口播后再准备。':adopted===6?`本单${kinds[state.kind]}已全部采用，可继续下一项准备。`:ready?`有 ${ready} 项${kinds[state.kind]}待核对，确认后再采用。`:`批量准备${kinds[state.kind]}，完成后在同一处集中核对。`;
  const visible=visibleIds();
  $('#filterSummary').textContent=`${visible.length} 个镜头 · ${kinds[state.kind]}视图`;
  $('#rows').innerHTML=visible.map(i=>`<tr class="${selected.has(i)?'selected':''}"><td><label class="check-target"><input id="select-${i}" data-select="${i}" type="checkbox" ${selected.has(i)?'checked':''} aria-label="选择镜头 ${number(i)}"></label></td><th scope="row"><div class="shot-identity"><img src="${asset(i?'room.png':'empty.png')}" alt="" width="31" height="44"><span>${number(i)}</span></div></th><td class="script-cell"><p>${escape(scriptSegments[i].narration)}</p><small>${escape(scriptSegments[i].visual)}</small></td><td class="status-cell">${statusButton(i,'voice')}</td><td class="status-cell">${statusButton(i,'visual')}</td><td class="status-cell">${statusButton(i,'captions')}</td><td class="duration">${durations[i].toFixed(2)} s</td><td><button class="row-action" data-inspect="${i}" aria-label="查看镜头 ${number(i)}">查看 ↗</button></td></tr>`).join('');
  $('#selectAll').checked=visible.length>0&&visible.every(i=>selected.has(i));
  $('#selectAll').indeterminate=visible.some(i=>selected.has(i))&&!$('#selectAll').checked;
  $('#selectAll').disabled=!visible.length;$('#empty').hidden=!!visible.length;
  const pending=state.shots.flatMap((s,i)=>Object.keys(kinds).filter(k=>['queued','running'].includes(s[k].status)).map(k=>({i,k})));
  $('#activity').hidden=!pending.length;
  if(pending.length)$('#activity').innerHTML=`<span>模拟队列 · ${pending.length} 项处理中</span><progress aria-label="本批模拟任务完成进度" max="6" value="${6-Math.min(6,pending.length)}"></progress><span class="muted">可先核对已完成项</span>`;
  if(focusId?.startsWith('select-'))document.getElementById(focusId)?.focus();
}
function openPanel(title,eyebrow='分镜台',wide=true){
  $('#panelTitle').textContent=title;$('#panelEyebrow').textContent=eyebrow;$('#panel').classList.toggle('wide',wide);
  if(!$('#panel').open)$('#panel').showModal();
}
function closePanel(){$('#panel').close();}
function textFor(i,kind){return kind==='visual'?scriptSegments[i].visual:scriptSegments[i].narration;}
function media(i,kind){
  if(kind==='voice')return `<div class="narration">${escape(scriptSegments[i].narration)}</div><audio controls preload="metadata" src="${asset(`voice-${number(i)}.mp3`)}" aria-label="镜头 ${number(i)} 口播试听"></audio><p class="review-text">使用已有测试口播作试听样例。文字即上方逐字稿。</p>`;
  if(kind==='captions')return `<div class="review-preview"><figure><img src="${asset(i?'room.png':'empty.png')}" width="120" height="190" alt="${escape(scriptSegments[i].visual)}"><figcaption>首条字幕排版示意，非本次真实渲染</figcaption></figure></div><div class="caption-demo"><p>${escape(scriptSegments[i].captions[0].text.match(new RegExp(`.{1,${entry(i,'captions').config?.chars??effective('captions').chars}}`,'gu'))?.join('\n')??'')}</p></div><p class="review-text">${escape(scriptSegments[i].narration)}<br>此处仅演示核对与采用，正式实现需检查实际渲染。</p>`;
  const old=entry(i,'visual').warning&&i===0;
  const src=old?`${asset('old-opening.mp4')}`:`${asset('final.mp4')}#t=${starts[i]},${starts[i]+durations[i]}`;
  return `<div class="review-preview"><figure><video controls muted preload="metadata" playsinline src="${src}" aria-label="镜头 ${number(i)} 示例画面" data-start="${old?0:starts[i]}" data-end="${old?4:starts[i]+durations[i]}"></video><figcaption>已有测试片段，静音预览</figcaption></figure></div><p class="review-text">${escape(scriptSegments[i].visual)}</p>`;
}
function bindMedia(){
  document.querySelectorAll('#panel video[data-end]').forEach(v=>{
    v.addEventListener('loadedmetadata',()=>{v.currentTime=Number(v.dataset.start);},{once:true});
    v.addEventListener('timeupdate',()=>{if(v.currentTime>=Number(v.dataset.end)){v.pause();v.currentTime=Number(v.dataset.start);}});
  });
}
function openReview(ids=readyIds(),active=ids[0]){
  if(!ids.length){toast('没有可核对的候选。');return;}
  mode='review';reviewIds=[...ids];activeId=active??ids[0];renderReview();openPanel(`集中核对 · ${kinds[state.kind]}`,'核对候选 → 标记通过 → 采用');
}
function renderReview(){
  const focused=document.activeElement;
  const restore=focused?.matches('[data-pass-next]')?'[data-pass-next]':focused?.matches('[data-next]')?'[data-next]':focused?.matches('[data-prev]')?'[data-prev]':focused?.matches('[data-pass]')?`[data-pass="${focused.dataset.pass}"]`:focused?.matches('[data-review-shot]')?`[data-review-shot="${focused.dataset.reviewShot}"]`:null;
  const kind=state.kind,passed=reviewIds.filter(i=>entry(i,kind).reviewed&&entry(i,kind).status==='ready'),current=entry(activeId,kind),n=reviewIds.indexOf(activeId);
  $('#panelBody').innerHTML=`<div class="drawer-toolbar"><strong>${reviewIds.length} 个候选</strong><span class="muted">逐项试听或预览，通过后勾选；异常项留待处理。</span></div><div class="review-layout"><div class="review-list" role="group" aria-label="待核对候选">${reviewIds.map(i=>{const e=entry(i,kind);return `<div class="review-item ${i===activeId?'current':''}"><label class="check-target"><input data-pass="${i}" type="checkbox" ${e.reviewed?'checked':''} ${e.warning?'disabled':''} aria-label="镜头 ${number(i)} 核对通过"></label><button data-review-shot="${i}" ${i===activeId?'aria-current="true"':''}><strong>镜头 ${number(i)} <span class="muted">${durations[i].toFixed(2)} s</span></strong><small>${escape(textFor(i,kind))}</small>${e.warning?'<small class="warning-small">需处理 · 暂不能采用</small>':''}</button></div>`;}).join('')}</div><article class="inspector-body"><p class="kind-label">${n+1} / ${reviewIds.length}</p><h3>镜头 ${number(activeId)} · ${kinds[kind]}</h3>${media(activeId,kind)}${current.warning?`<div class="warning-box"><strong>发现问题</strong><p>${escape(current.warning)}</p><button class="quiet" data-hold="${activeId}">暂不采用，移出本轮</button></div>`:''}<dl class="facts"><div><dt>本次配置</dt><dd>${escape(configLabel(kind,current.config??effective(kind)))}</dd></div><div><dt>采用影响</dt><dd>${kind==='voice'?'采用实际口播时长；字幕需重新核对':kind==='visual'?'保留镜头目标时长与其他已采用内容':'仅更新本镜头字幕'}</dd></div></dl><div class="review-controls"><button class="secondary" data-prev ${n===0?'disabled':''}>上一条</button><button class="secondary" data-next ${n===reviewIds.length-1?'disabled':''}>下一条</button><button class="primary" data-pass-next ${current.warning?'disabled':''}>${current.reviewed?'已通过，下一条':'通过并下一条'}</button></div></article></div><footer class="drawer-footer"><span class="muted">已通过 ${passed.length} / ${reviewIds.length} 项</span><button class="quiet" data-action="close">稍后继续</button><button class="primary" id="adoptPassed" ${passed.length?'':'disabled'}>采用已通过的 ${passed.length} 项</button></footer>`;
  bindMedia();
  if(restore&&$('#panel').open)$('#panelBody').querySelector(restore)?.focus();
}
function openShot(i,kind=state.kind){
  state.kind=kind;persist();renderMain();
  const e=entry(i,kind);
  if(e.status==='ready'){const ids=state.shots.map((_,j)=>j).filter(j=>entry(j,kind).status==='ready');openReview(ids,i);return;}
  mode='inspect';activeId=i;
  $('#panelBody').innerHTML=`<div class="form-scroll"><h3 class="section-title">镜头 ${number(i)} · ${kinds[kind]} · ${labels[e.status]}</h3><p class="review-text">${escape(textFor(i,kind))}</p>${['adopted'].includes(e.status)?media(i,kind):''}${e.status==='failed'?`<div class="error-box">${escape(e.message)}</div><button class="primary" data-retry="${i}">仅重试镜头 ${number(i)}</button>`:e.status==='unknown'?`<div class="warning-box">${escape(e.message)}</div><button class="primary" data-reconcile="${i}">查询原请求回执（模拟）</button><p class="review-text">不会再次提交生成。</p>`:e.status==='empty'?`<p class="review-text">${kind==='captions'&&entry(i,'voice').status!=='adopted'?'先采用本镜头口播，再对齐字幕。':'关闭面板后可在总览选择镜头，批量准备。'}</p>`:['running','queued'].includes(e.status)?'<p class="review-text">模拟任务正在运行，可关闭面板查看总览进度。</p>':'<p class="success">已采用，可继续处理其他镜头。</p>'}</div><footer class="drawer-footer"><span class="muted">镜头 ${number(i)}</span><button class="primary" data-action="close">返回总览</button></footer>`;
  openPanel(`镜头 ${number(i)}`);bindMedia();
}
function openConfirm(title,html,label,action){
  confirmationAction=action;$('#confirmTitle').textContent=title;$('#confirmBody').innerHTML=html;$('#commit').textContent=label;$('#commit').disabled=false;$('#cancelConfirm').disabled=false;
  $('#confirm').showModal();
}
function requestPreparation(ids=prepareIds()){
  const kind=state.kind;
  ids=ids.filter(i=>eligible(i,kind));if(!ids.length){toast('当前没有符合条件的待准备项。');return;}
  const config={...effective(kind)};
  const excluded=scopedIds().length-ids.length;
  openConfirm(`批量准备 · ${kinds[kind]}`,`<p class="review-text">${ids.length} 个镜头分别创建独立模拟任务。${excluded?`另有 ${excluded} 项不符合条件，不重复提交。`:''}</p><div class="summary-line"><span>共同配置</span><strong>${escape(configLabel(kind,config))}</strong></div><table class="confirm-table"><caption class="sr-only">本次准备范围</caption><thead><tr><th scope="col">镜头</th><th scope="col">本次输入</th><th scope="col">目标时长</th></tr></thead><tbody>${ids.map(i=>`<tr><th scope="row">${number(i)}</th><td><p>${escape(textFor(i,kind))}</p>${kind==='visual'?`<small>首帧：${escape(scriptSegments[i].settings.firstFrame)} · 保留独立镜头提示词</small>`:''}</td><td>${durations[i].toFixed(2)} s</td></tr>`).join('')}</tbody></table><p class="note">此 Demo 只推进模拟队列，费用不适用，不产生真实请求。</p>`,`确认准备 ${ids.length} 项`,()=>{
    const now=Date.now(),batch=++state.sequence;
    ids.forEach((i,n)=>{const prior=entry(i,kind);state.shots[i][kind]={status:'queued',start:now+300+Math.floor(n/2)*1500,end:now+1600+Math.floor(n/2)*1500,config:{...config},request:`demo-${batch}-${kind}-${number(i)}`,reviewed:false,attempt:(prior.attempt??0)+1};});
    log(`批量准备 ${ids.length} 项${kinds[kind]}`,ids.map(i=>`${number(i)} · demo-${batch}-${kind}-${number(i)}`).join('；'));
    if($('#panel').open)closePanel();selected.clear();filter='all';renderMain();toast(`已创建 ${ids.length} 个模拟任务，完成后可集中核对。`);
  });
}
function requestAdoption(){
  const kind=state.kind,ids=reviewIds.filter(i=>entry(i,kind).reviewed&&entry(i,kind).status==='ready'&&!entry(i,kind).warning);
  if(!ids.length)return;
  openConfirm(`采用前核对 · ${kinds[kind]}`,`<p class="review-text">仅采用已标记通过的 ${ids.length} 项，其余候选保持原状。</p><table class="confirm-table"><caption class="sr-only">本次采用及影响</caption><thead><tr><th scope="col">镜头</th><th scope="col">采用内容</th><th scope="col">影响</th></tr></thead><tbody>${ids.map(i=>`<tr><th scope="row">${number(i)}</th><td>${escape(textFor(i,kind))}</td><td>${kind==='voice'?`${durations[i].toFixed(2)} s<br>更新口播与镜头时长`:kind==='visual'?'替换画面<br>保留其他轨道':'更新本镜头字幕'}</td></tr>`).join('')}</tbody></table><p class="note">${kind==='voice'?'字幕随采用口播重新核对；不重新生成已确认画面。':'保留已采用口播和人工修改，未勾选候选不受影响。'}本次操作仅作用于 Demo。</p>`,`确认采用 ${ids.length} 项`,()=>{
    ids.forEach(i=>{state.shots[i][kind]={...entry(i,kind),status:'adopted',reviewed:true};});
    log(`采用 ${ids.length} 项${kinds[kind]}`,ids.map(i=>`镜头 ${number(i)}`).join('、'));
    selected.clear();renderMain();
    $('#panelBody').innerHTML=`<div class="receipt"><h3>✓ 已采用 ${ids.length} 项${kinds[kind]}</h3><p>未通过的候选仍保留待核对。<br>${kind==='voice'?'接下来可批量准备画面或对齐字幕。':'可回到总览继续其他准备。'}</p><button class="primary" data-action="close">返回分镜台</button>${kind==='voice'?'<button class="quiet" data-continue="visual">继续准备画面 →</button>':''}</div>`;
  });
}
function openSettings(){
  mode='settings';const kind=state.kind,patch=state.settings[kind];
  const field=(name,label,choices)=>`<label class="field" for="setting-${name}">${label}<select id="setting-${name}" name="${name}"><option value="">不调整</option>${choices.map(v=>`<option value="${v}" ${patch[name]===v?'selected':''}>${v}</option>`).join('')}</select></label>`;
  $('#panelBody').innerHTML=`<form id="settingsForm" class="form-scroll"><h3>本单${kinds[kind]}设置</h3><p class="review-text">只应用填写的字段；未填写则沿用镜头现有设置。保存后用于后续准备，不改已有候选。</p><div class="settings-grid">${kind==='voice'?field('model','模型',['seed-tts-2.0'])+field('voice','声音',['明亮女声','沉稳男声'])+field('rate','语速',['0.9','1','1.1']):kind==='visual'?field('model','模型',['MiniMax-H3-Lite'])+field('resolution','分辨率',['768P','1080P']):field('lines','字幕最大行数',['1','2'])+field('chars','每行最大字数',['12','14','16'])}</div><div class="summary-line"><span>当前生效</span><strong>${escape(configLabel(kind))}</strong></div><p class="note">画面提示词、首帧和时长由各镜头分别提供，不参与批量复制。模型选项仅作交互示意。</p></form><footer class="drawer-footer"><span class="muted">仅更新本单后续制作选择</span><button class="secondary" data-action="close">取消</button><button class="primary" type="submit" form="settingsForm">保存设置</button></footer>`;
  $('#settingsForm').addEventListener('submit',e=>{e.preventDefault();const values=Object.fromEntries(new FormData(e.target));state.settings[kind]=Object.fromEntries(Object.entries(values).filter(([,v])=>v!==''));log(`保存${kinds[kind]}制作设置`,'未填字段保持原镜头设置');closePanel();renderMain();toast('已保存，仅用于后续准备。');});
  openPanel('本单制作设置');
}
function simplePanel(title,html){mode='simple';$('#panelBody').innerHTML=`<div class="form-scroll">${html}</div><footer class="drawer-footer"><button class="primary" data-action="close">返回分镜台</button></footer>`;openPanel(title);}
function tick(){
  const now=Date.now();let changed=false;
  state.shots.forEach(s=>Object.keys(kinds).forEach(kind=>{const e=s[kind];if(!['queued','running'].includes(e.status))return;const status=now>=e.end?'ready':now>=e.start?'running':'queued';if(status!==e.status){e.status=status;changed=true;}}));
  if(changed){persist();renderMain();if(!state.shots.some(s=>Object.keys(kinds).some(k=>['queued','running'].includes(s[k].status))))toast('模拟任务已完成，可集中核对后采用。');}
}
function changeScenario(scenario){
  state=fresh(scenario);selected.clear();filter='all';persist();if($('#panel').open)closePanel();renderMain();toast(scenario==='exceptions'?'已载入异常样例：画面问题、明确失败及结果未知。':'已载入演示场景。');
}
$('#scenario').addEventListener('change',e=>changeScenario(e.target.value));
$('#reset').addEventListener('click',()=>openConfirm('重置演示？','<p>仅清空本原型的浏览器进度，重新载入当前演示场景。</p>','重置演示',()=>changeScenario(state.scenario)));
$('#clearSelection').addEventListener('click',()=>{selected.clear();renderMain();});
$('#selectAll').addEventListener('change',e=>{visibleIds().forEach(i=>e.target.checked?selected.add(i):selected.delete(i));renderMain();});
$('#rows').addEventListener('change',e=>{if(e.target.matches('[data-select]')){const i=Number(e.target.dataset.select);e.target.checked?selected.add(i):selected.delete(i);renderMain();}});
$('#prepare').addEventListener('click',()=>requestPreparation());$('#review').addEventListener('click',()=>openReview());$('#settings').addEventListener('click',openSettings);
$('#closePanel').addEventListener('click',closePanel);
$('#panel').addEventListener('close',()=>{$('#panel').querySelectorAll('audio,video').forEach(v=>v.pause());$('#panel').returnValue='';mode='';});
function cancelConfirm(){if(!commitBusy)$('#confirm').close();}
$('#closeConfirm').addEventListener('click',cancelConfirm);$('#cancelConfirm').addEventListener('click',cancelConfirm);
$('#confirm').addEventListener('cancel',e=>{if(commitBusy)e.preventDefault();});
$('#confirm').addEventListener('close',()=>{confirmationAction=null;$('#confirm').returnValue='';});
$('#commit').addEventListener('click',()=>{
  if(commitBusy||!confirmationAction)return;const action=confirmationAction;commitBusy=true;$('#commit').disabled=true;$('#cancelConfirm').disabled=true;
  try{action();$('#confirm').close();}finally{commitBusy=false;}
});
$('#help').addEventListener('click',()=>simplePanel('如何体验这个流程',`<ol class="note-list"><li>在总览选择镜头，或直接处理全部待准备项。</li><li>点击“批量准备”，核对配置与范围，一次提交模拟任务。</li><li>完成后进入“集中核对”，逐项试听或预览，通过并下一条。</li><li>点击“采用已通过的项”，确认影响后回到总览。</li><li>切换“异常与恢复”，体验失败单独重试、未知先查回执、有问题的候选暂不采用。</li></ol><p class="review-text">所有状态与费用均为演示；媒体来自此前本地测试，不会实际生成、计费、导出或修改生产单。刷新保留进度，重置可重新体验。</p>`));
$('#history').addEventListener('click',()=>simplePanel('操作记录',state.events.length?state.events.map(e=>`<div class="record"><strong>${escape(e.text)}</strong><small>${escape(e.time)} · ${escape(e.detail)}</small></div>`).join(''):'<p class="review-text">暂无操作，提交准备或采用后会在此记录。</p>'));
document.addEventListener('click',event=>{
  const b=event.target.closest('button');if(!b||b.disabled)return;
  if(b.dataset.kind){state.kind=b.dataset.kind;selected.clear();filter='all';persist();renderMain();}
  if(b.dataset.filter){filter=b.dataset.filter;selected.clear();renderMain();}
  if(b.dataset.inspect!==undefined)openShot(Number(b.dataset.inspect),b.dataset.inspectKind??state.kind);
  if(b.dataset.reviewShot!==undefined){activeId=Number(b.dataset.reviewShot);renderReview();}
  if(b.hasAttribute('data-next')||b.hasAttribute('data-prev')){const delta=b.hasAttribute('data-next')?1:-1;activeId=reviewIds[reviewIds.indexOf(activeId)+delta];renderReview();}
  if(b.hasAttribute('data-pass-next')){entry(activeId).reviewed=true;persist();const next=reviewIds[reviewIds.indexOf(activeId)+1];if(next!==undefined)activeId=next;renderReview();}
  if(b.id==='adoptPassed')requestAdoption();
  if(b.dataset.hold!==undefined){const held=Number(b.dataset.hold);reviewIds=reviewIds.filter(i=>i!==held);log(`镜头 ${number(held)} 暂不采用`,'候选保留，继续处理其他候选');if(reviewIds.length){activeId=reviewIds[0];renderReview();}else{closePanel();toast('本轮候选已移出，问题候选仍保留。');}}
  if(b.dataset.retry!==undefined)requestPreparation([Number(b.dataset.retry)]);
  if(b.dataset.reconcile!==undefined){const i=Number(b.dataset.reconcile);state.shots[i][state.kind]={status:'ready',reviewed:false,request:'demo-recovered-original',config:effective()};log(`找回镜头 ${number(i)} 原请求结果`,'仅查询模拟回执，未再次生成');closePanel();renderMain();toast('已找回原请求结果，加入待核对；未重新提交。');}
  if(b.dataset.continue){closePanel();state.kind=b.dataset.continue;filter='all';persist();renderMain();}
  if(b.dataset.action==='close')closePanel();
  if(b.dataset.action==='all'){filter='all';renderMain();}
  if(b.dataset.action==='overview'){filter='all';renderMain();}
  if(b.dataset.action==='script')simplePanel('已确认脚本',scriptSegments.map((s,i)=>`<div class="record"><strong>镜头 ${number(i)}</strong><p>${escape(s.narration)}</p><small>${escape(s.visual)}</small></div>`).join(''));
  if(b.dataset.action==='editing'){
    const adopted=state.shots.reduce((n,s)=>n+Object.keys(kinds).filter(k=>s[k].status==='adopted').length,0);
    simplePanel('剪辑草稿预览',`<p class="review-text">当前 Demo 已采用 ${adopted} / 18 项。此入口仅示意与剪辑草稿的衔接，不创建真实工程。</p><div class="editing-grid"><video controls preload="metadata" src="${asset('final.mp4')}" aria-label="此前测试成片，非本次生成"></video><div><h3>已有成片示例</h3><p class="review-text">此视频来自此前乔迁测试，与本轮模拟采用状态无关。</p>${scriptSegments.map((s,i)=>`<div class="record">镜头 ${number(i)} · ${durations[i].toFixed(2)} s<small>${escape(s.narration)}</small></div>`).join('')}</div></div>`);
  }
  if(b.dataset.action==='delivery')simplePanel('检查与交付',`<p class="review-text">此 Demo 聚焦批量准备、集中核对和采用，交付沿用原 C 布局。完成素材准备后，正式流程仍需检查实际剪辑与导出。</p><a href="../?layout=C&step=delivery">查看原交付 Demo ↗</a>`);
});
$('#panelBody').addEventListener('change',event=>{if(event.target.matches('[data-pass]')){entry(Number(event.target.dataset.pass)).reviewed=event.target.checked;persist();renderReview();}});
// Pause earlier media before starting another preview.
document.addEventListener('play',event=>{if(event.target.matches('audio,video'))document.querySelectorAll('audio,video').forEach(v=>{if(v!==event.target)v.pause();});},true);
renderMain();tick();setInterval(tick,400);
