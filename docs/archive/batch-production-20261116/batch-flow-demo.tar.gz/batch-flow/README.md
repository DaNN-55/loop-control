# 提效流程 Demo · C 布局

[打开 Demo](http://127.0.0.1:8766/batch-flow/)。独立静态原型，不调用生产 API，不产生付费请求，不改变正式工程。

## 体验路径

1. 在镜头总览选择范围，或直接点击「批量准备 6」。提交前一次核对各镜头输入和本次配置。
2. 模拟队列完成后点击「集中核对」。在抽屉中连续试听／预览，用「通过并下一条」标记通过，也可保留到稍后继续。
3. 点击「采用已通过的项」，汇总核对采用影响；确认后只更新本轮勾选项，总览随之更新。

口播、画面、字幕共用总览与核对方式。字幕只准备已有采用口播的镜头。本单设置只保存已填写字段，已有候选的配置快照不变。

顶部可切换「直接体验集中核对」和「异常与恢复」。异常样例含：有问题的候选暂不采用、失败镜头单独重试、未知结果查询原回执（模拟），不重提生成。切换场景／重置会清空此 Demo 的当前进度；正常刷新／重新打开保留进度。

媒体沿用父目录已有测试文件。模拟生成不会改变音视频，字幕排版仅为首条字幕示意；「剪辑草稿」只展示此前测试成片，不代表本轮采用后完成了真实工程更新或导出。模型／声音选择也仅展示交互。

## 运行

从项目根目录执行（已有 8766 服务时不重复启动）：

```sh
python3 -m http.server 8766 --bind 127.0.0.1 --directory docs/research/production-followup-20261116/demo
```

文件：`index.html`、`flow.css`、`flow.js`。复用父目录样式与现有媒体，无新增依赖。浏览器状态仅写入本原型专用 localStorage 键 `loop-control:batch-flow-demo:v1`；CSP 的 `connect-src 'none'` 禁止此页发起 API 请求。

## 验证证据

- `validation.json`：实际 Chromium 交互断言及尺寸核验。
- `browser-network.json`：浏览器 XHR／fetch 请求检查。
- `accessibility.json`：总览 axe WCAG A／AA 检查，自动检查不能替代完整无障碍验收。
- `overview.png`／`preparation.png`／`review.png`／`adoption.png`／`exceptions.png`／`mobile.png`：主要交互截图。
- 未运行正式产品全套测试或真实导出：本任务仅制作独立 Demo，正式实现待用户确认交互后推进。

结果：16 项浏览器核验通过，包含六镜头口播／画面／字幕共 18 项的完整模拟准备与采用。四档宽度无整页横向溢出；总览 axe 为 0 violations、1 组装饰图形对比度 incomplete；浏览器 XHR／fetch 为 0。视频预览的字幕／描述仍需人工判断，未宣称完整无障碍验收。语法检查通过。

## Modern Web Guidance

- **`dialog`**：我用原生 `showModal()` 实现抽屉与采用确认，不重复实现焦点陷阱；未设置 `closedby=any`，关闭按钮和 Escape 均可用。模态面板与遮罩均设置滚动约束（“DON'T add `role="dialog"`, `aria-modal`”）。
- **`accessibility`**：我保留原生复选框、表头 scope 和逐镜头控件名称，核对列表重绘后保持当前操作的键盘焦点，避免「通过并下一条」后焦点丢失（“Provide a logical tab order”）。
